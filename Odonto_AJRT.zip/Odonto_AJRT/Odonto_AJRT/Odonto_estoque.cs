﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Odonto_AJRT
{
    public partial class Odonto_estoque : Form
    {
        String rdado;
        public Odonto_estoque(String Dado)
        {
            InitializeComponent();
            rdado = Dado;
            preencher();
            WindowState = FormWindowState.Maximized;

            dataGridView.BorderStyle = BorderStyle.None;
            dataGridView.BackgroundColor = Color.White;

            dataGridView.EnableHeadersVisualStyles = false;
            dataGridView.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 108, 146);
            dataGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        }

        void preencher() {
            string MyConnection = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True; convert zero datetime=true";
            MySqlConnection MyConn = new MySqlConnection(MyConnection);
            MyConn.Open(); //EU SOU A ULTIMA VERSÃO
            MySqlDataAdapter sqlda = new MySqlDataAdapter("select * from odonto_ajrt.tb_estoque", MyConnection);
            DataTable dtbl = new DataTable();
            sqlda.Fill(dtbl);
            dataGridView.AutoGenerateColumns = false;
            dataGridView.DataSource = dtbl;

            MyConn.Close();
        }

        private void ClearData()
        {
            txt_referencia.Text = "";
            txt_desc.Text = "";
            txt_marca.Text = "";
            txt_categoria.Text = "";
            txt_p_uni.Text = "0";
            Validade.Text = "20/04/2019";
            txt_unidade.Text = "";
            txt_quantidade.Text = "0";
            txt_p_total.Text = "0";
            txt_fornecedor.Text = "";
            entrega.Text = "20/04/2019";
        }

        private void BEsquerda_Click(object sender, EventArgs e)
        {
            main_sec_odonto objFrmMain = new main_sec_odonto(rdado);
            this.Hide();
            objFrmMain.Show();
        }

        private void txt_unidade_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsLetter(e.KeyChar)) && !(e.KeyChar == (char)Keys.Enter) && !(e.KeyChar == (char)Keys.Back))

            {
                txt_unidade.MaxLength = 2;//aaaa
                e.Handled = true;

            }
        }

        private void txt_quantidade_Leave(object sender, EventArgs e)
        {
            txt_p_total.Text = Convert.ToString(Convert.ToDouble(txt_p_uni.Text) * Convert.ToDouble(txt_quantidade.Text));
        }

        private void Registrar_Click(object sender, EventArgs e)
        {
            txt_quantidade_Leave(null, null);
            if (txt_referencia.Text != "")
            {
                if (txt_desc.Text != "")
                {
                    if (txt_marca.Text != "")
                    {
                        if (txt_categoria.Text != "")
                        {
                            if (txt_p_uni.Text != "")
                            {
                                if (Validade.Value.Date >= DateTime.Now)
                                {
                                    if (txt_unidade.Text != "")
                                    {
                                        if (txt_quantidade.Text != "")
                                        {
                                            if (txt_p_total.Text != "")
                                            {
                                                if (txt_fornecedor.Text != "")
                                                {
                                                    try
                                                    {
                                                        txt_p_uni.Text = txt_p_uni.Text.Replace(',', '.');
                                                        txt_p_total.Text = txt_p_total.Text.Replace(',', '.');
                                                        //This is my connection string i have assigned the database file address path  
                                                        string MyConnection1 = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
                                                        //This is my insert query in which i am taking input from the user through windows forms  
                                                        string Query1 = "insert into tb_estoque(Estoque_referencia,Estoque_desc,Estoque_marca,Estoque_categoria,Estoque_p_unidade,Estoque_validade,Estoque_unidade,Estoque_quantidade,Estoque_p_total,Estoque_fornecedor,Estoque_entrega) values('" + this.txt_referencia.Text + "','" + this.txt_desc.Text + "','" + this.txt_marca.Text + "','" + this.txt_categoria.Text + "','" + this.txt_p_uni.Text + "','" + this.Validade.Text + "','" + this.txt_unidade.Text + "','" + this.txt_quantidade.Text + "','" + this.txt_p_total.Text + "','" + this.txt_fornecedor.Text + "','" + this.entrega.Text + "');";
                                                        //This is  MySqlConnection here i have created the object and pass my connection string.  
                                                        MySqlConnection MyConn1 = new MySqlConnection(MyConnection1);
                                                        //This is command class which will handle the query and connection object.  
                                                        MySqlCommand MyCommand1 = new MySqlCommand(Query1, MyConn1);
                                                        MySqlDataReader MyReader1;
                                                        MyConn1.Open();
                                                        MyReader1 = MyCommand1.ExecuteReader();     // Here our query will be executed and data saved into the database.  

                                                        MessageBox.Show("Item cadastrado");
                                                        while (MyReader1.Read())
                                                        {
                                                        }
                                                        MyConn1.Close();

                                                    }
                                                    catch (Exception ex)
                                                    {
                                                        MessageBox.Show(ex.Message);
                                                    }

                                                    preencher();
                                                    ClearData();
                                                }
                                                else
                                                {
                                                    MessageBox.Show("Informe o fornecedor!!");
                                                }
                                            }
                                            else
                                            {
                                                MessageBox.Show("Informe o preço total!!");
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show("Informe a quantidade do produto a ser cadastrado!!");
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Informe a unidade de medida do produto!!");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Não é possível cadastrar um produto fora da validade!!");
                                }

                            }
                            else
                            {
                                MessageBox.Show("Informe o preço por unidade!!");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Informe a categoria do produto!!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Informe a marca do produto!!");
                    }
                }
                else
                {
                    MessageBox.Show("Informe a descrição do produto!!");
                }
            }
            else
            {
                MessageBox.Show("Informe a referencia!!");
            }
        }

        private void txt_p_uni_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsNumber(e.KeyChar)) && !(e.KeyChar == (char)Keys.Enter) && !(e.KeyChar == (char)Keys.Back) && (e.KeyChar != ',') && (e.KeyChar != '.'))

            {
                txt_unidade.MaxLength = 2;//aaaa
                e.Handled = true;

            }
        }

        private void txt_quantidade_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsNumber(e.KeyChar)) && !(e.KeyChar == (char)Keys.Enter) && !(e.KeyChar == (char)Keys.Back))

            {
                txt_unidade.MaxLength = 2;//aaaa
                e.Handled = true;

            }
        }

        private void dataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_referencia.Text = dataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
            txt_desc.Text = dataGridView.Rows[e.RowIndex].Cells[1].Value.ToString();
            txt_marca.Text = dataGridView.Rows[e.RowIndex].Cells[2].Value.ToString();
            txt_categoria.Text = dataGridView.Rows[e.RowIndex].Cells[3].Value.ToString();
            txt_p_uni.Text = dataGridView.Rows[e.RowIndex].Cells[4].Value.ToString();
            Validade.Text = dataGridView.Rows[e.RowIndex].Cells[5].Value.ToString();
            txt_unidade.Text = dataGridView.Rows[e.RowIndex].Cells[6].Value.ToString();
            txt_quantidade.Text = dataGridView.Rows[e.RowIndex].Cells[7].Value.ToString();
            txt_p_total.Text = dataGridView.Rows[e.RowIndex].Cells[8].Value.ToString();
            txt_fornecedor.Text = dataGridView.Rows[e.RowIndex].Cells[9].Value.ToString();
            entrega.Text = dataGridView.Rows[e.RowIndex].Cells[10].Value.ToString();

            Registrar.Visible = false;
        }

        private void Editar_Click(object sender, EventArgs e)
        {
            txt_quantidade_Leave(null, null);
            if (txt_referencia.Text != "")
            {
                if (txt_desc.Text != "")
                {
                    if (txt_marca.Text != "")
                    {
                        if (txt_categoria.Text != "")
                        {
                            if (txt_p_uni.Text != "")
                            {
                                if (Validade.Value.Date >= DateTime.Now)
                                {
                                    if (txt_unidade.Text != "")
                                    {
                                        if (txt_quantidade.Text != "")
                                        {
                                            if (txt_p_total.Text != "")
                                            {
                                                if (txt_fornecedor.Text != "")
                                                {
                                                    try
                                                    {
                                                        txt_p_uni.Text = txt_p_uni.Text.Replace(',', '.');
                                                        txt_p_total.Text = txt_p_total.Text.Replace(',', '.');
                                                        //This is my connection string i have assigned the database file address path  
                                                        string MyConnection1 = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
                                                        //This is my insert query in which i am taking input from the user through windows forms  
                                                        string Query1 = "update tb_estoque set Estoque_referencia='" + this.txt_referencia.Text + "',Estoque_desc ='" + this.txt_desc.Text + "',Estoque_marca='" + this.txt_marca.Text + "',Estoque_categoria='" + this.txt_categoria.Text + "',Estoque_p_unidade='" + this.txt_p_uni.Text + "',Estoque_validade='" + this.Validade.Text + "',Estoque_unidade='" + this.txt_unidade.Text + "',Estoque_quantidade='" + this.txt_quantidade.Text + "',Estoque_p_total='" + this.txt_p_total.Text + "',Estoque_fornecedor='" + this.txt_fornecedor.Text + "',Estoque_entrega='" + this.entrega.Text + "' where Estoque_referencia='" + this.txt_referencia.Text + "';";//ARRUMAR
                                                        //This is  MySqlConnection here i have created the object and pass my connection string.  
                                                        MySqlConnection MyConn1 = new MySqlConnection(MyConnection1);
                                                        //This is command class which will handle the query and connection object.  
                                                        MySqlCommand MyCommand1 = new MySqlCommand(Query1, MyConn1);
                                                        MySqlDataReader MyReader1;
                                                        MyConn1.Open();
                                                        MyReader1 = MyCommand1.ExecuteReader();     // Here our query will be executed and data saved into the database.  

                                                        MessageBox.Show("Item Editado");
                                                        while (MyReader1.Read())
                                                        {
                                                        }
                                                        MyConn1.Close();

                                                    }
                                                    catch (Exception ex)
                                                    {
                                                        MessageBox.Show(ex.Message);
                                                    }

                                                    preencher();
                                                    ClearData();
                                                    Registrar.Visible = true;
                                                }
                                                else
                                                {
                                                    MessageBox.Show("Informe o fornecedor!!");
                                                }
                                            }
                                            else
                                            {
                                                MessageBox.Show("Informe o preço total!!");
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show("Informe a quantidade do produto a ser cadastrado!!");
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Informe a unidade de medida do produto!!");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Não é possível cadastrar um procuto fora da validade!!");
                                }

                            }
                            else
                            {
                                MessageBox.Show("Informe o preço por unidade!!");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Informe a categoria do produto!!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Informe a marca do produto!!");
                    }
                }
                else
                {
                    MessageBox.Show("Informe a descrição do produto!!");
                }
            }
            else
            {
                MessageBox.Show("Informe a referencia!!");
            }
        }

        private void Excluir_Click(object sender, EventArgs e)
        {
            if (txt_referencia.Text != "")
            {
                string MyConnection1 = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
                string Query1 = "delete from tb_estoque where Estoque_referencia = "+txt_referencia.Text+"";
                MySqlConnection MyConn1 = new MySqlConnection(MyConnection1);
                //This is command class which will handle the query and connection object.  
                MySqlCommand MyCommand1 = new MySqlCommand(Query1, MyConn1);
                MySqlDataReader MyReader1;
                MyConn1.Open();
                MyReader1 = MyCommand1.ExecuteReader();     // Here our query will be executed and data saved into the database.  

                MessageBox.Show("Item Excluido");//ULTIMA ALTERAÇÃO 20/04
                while (MyReader1.Read())
                {
                }
                MyConn1.Close();

            }else
            {
                MessageBox.Show("Please Select Record to Delete");
            }
            preencher();
            ClearData();
            Registrar.Visible = true;
        }

        private void Pesquisa_TextChanged(object sender, EventArgs e)
        {
            if (Pesquisa.Text != "")
            {
                string MyConnection = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True; convert zero datetime=true";
                MySqlConnection MyConn = new MySqlConnection(MyConnection);
                MyConn.Open();
                MySqlDataAdapter sqlda = new MySqlDataAdapter("select * from odonto_ajrt.tb_estoque where Estoque_referencia like '" + Pesquisa.Text + "%' ORDER BY Estoque_desc ASC;", MyConnection);
                DataTable dtbl = new DataTable();
                sqlda.Fill(dtbl);
                dataGridView.AutoGenerateColumns = false;
                dataGridView.DataSource = dtbl;

                MyConn.Close();
            }
            else { preencher(); }
        }

        private void Fechar_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void Maximizar_Click(object sender, EventArgs e)
        {
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
            this.Maximizar.Visible = false;
            this.Menorizar.Visible = true;
        }

        private void Menorizar_Click(object sender, EventArgs e)
        {
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Normal;
            this.Maximizar.Visible = true;
            this.Menorizar.Visible = false;
        }

        private void Minimizar_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void txt_p_uni_Leave(object sender, EventArgs e)
        {
            txt_p_total.Text = Convert.ToString(Convert.ToDouble(txt_p_uni.Text) * Convert.ToDouble(txt_quantidade.Text));
        }
    }
}
