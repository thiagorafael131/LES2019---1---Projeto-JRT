﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;//atualizado 190406

namespace Odonto_AJRT
{
    public partial class main_sec_odonto : Form
    {
        String rdado;
        //Trazer informações do funcionário
        public main_sec_odonto(String Dado)
        {
            InitializeComponent();
            rdado = Dado;
            WindowState = FormWindowState.Maximized;
            string MyConnection1 = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
            string sql = "SELECT * from tb_funcionario inner join tb_conta on tb_funcionario.Fun_id=tb_conta.FK_Fun_id " +
                "where Conta_usu = '" + rdado + "'";
            MySqlConnection MyConn1 = new MySqlConnection(MyConnection1);
            MyConn1.Open();
            MySqlCommand MyCommand1 = new MySqlCommand(sql, MyConn1);
            MySqlDataReader MyReader1 = MyCommand1.ExecuteReader();

            if (MyReader1.Read())
            {
                txt_nome.Text = MyReader1["Fun_nome"].ToString() +" "+ MyReader1["Fun_sobrenome"].ToString();
            }
            MyConn1.Close();

            string sql2 = "SELECT * from tb_cargo inner join tb_conta on tb_cargo.Cargo_id=tb_conta.FK_Cargo_id where Conta_usu = '" + rdado + "'";
            MySqlConnection MyConn2 = new MySqlConnection(MyConnection1);
            MyConn2.Open();
            MySqlCommand MyCommand2 = new MySqlCommand(sql2, MyConn2);
            MySqlDataReader MyReader2 = MyCommand2.ExecuteReader(); ;

            if (MyReader2.Read())
            {
                txt_cargo.Text = MyReader2["Cargo_nome"].ToString();
            }
            MyConn2.Close();
        }

        //Funções Básicas
        private void Minimizar_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void Menorizar_Click(object sender, EventArgs e)
        {
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Normal;
            this.Maximizar.Visible = true;
            this.Menorizar.Visible = false;
        }

        private void Maximizar_Click(object sender, EventArgs e)
        {
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
            this.Maximizar.Visible = false;
            this.Menorizar.Visible = true;
        }

        private void Fechar_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
        
        private void Cliente_Click(object sender, EventArgs e)
        {
            Odonto_cliente objFrmMain = new Odonto_cliente(rdado);
            this.Hide();
            objFrmMain.Show();
        }

        private void Consulta_Click(object sender, EventArgs e)
        {
            Odonto_consultas objFrmMain = new Odonto_consultas(rdado);
            this.Hide();
            objFrmMain.Show();
        }

        private void Estoque_Click(object sender, EventArgs e)
        {
            Odonto_estoque objFrmMain = new Odonto_estoque(rdado);
            this.Hide();
            objFrmMain.Show();
        }

        private void Finalizar_Click(object sender, EventArgs e)
        {
            form_1 objFrmMain = new form_1();
            this.Hide();
            objFrmMain.Show();
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            dataGridView1.Columns[1].HeaderText = monthCalendar1.SelectionRange.Start.ToString("yyyy-MM-dd");
            string MyConnection = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True; convert zero datetime=true";
            MySqlConnection MyConn = new MySqlConnection(MyConnection);
            MyConn.Open();
            MySqlDataAdapter sqlda = new MySqlDataAdapter("select Hor_hora, Concat(Fun_nome,' ',Fun_sobrenome) Medico from tb_horario left join tb_consulta on tb_horario.Hor_id=tb_consulta.FK_Hor_id left join tb_funcionario on tb_consulta.FK_Fun_id=tb_funcionario.Fun_id and Con_data='" + dataGridView1.Columns[1].HeaderText + "' order by Hor_hora;", MyConnection);
            DataTable dtbl = new DataTable();
            sqlda.Fill(dtbl);
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dtbl;

            MyConn.Close();

        }

        private void main_sec_odonto_Load(object sender, EventArgs e)
        {
            dataGridView1.Columns[1].HeaderText = DateTime.Now.ToString("yyyy-MM-dd");
            string MyConnection = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True; convert zero datetime=true";
            MySqlConnection MyConn = new MySqlConnection(MyConnection);
            MyConn.Open();
            MySqlDataAdapter sqlda = new MySqlDataAdapter("select Hor_hora, Concat(Fun_nome,' ',Fun_sobrenome) Medico from tb_horario left join tb_consulta on tb_horario.Hor_id=tb_consulta.FK_Hor_id left join tb_funcionario on tb_consulta.FK_Fun_id=tb_funcionario.Fun_id and Con_data='" + dataGridView1.Columns[1].HeaderText + "' order by Hor_hora;", MyConnection);
            DataTable dtbl = new DataTable();
            sqlda.Fill(dtbl);
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dtbl;

            MyConn.Close();

            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.BackgroundColor = Color.White;

            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 108, 146);
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        }
    }
}
