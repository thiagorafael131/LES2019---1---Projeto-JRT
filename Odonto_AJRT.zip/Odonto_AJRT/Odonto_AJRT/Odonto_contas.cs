﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Globalization;

namespace Odonto_AJRT
{
    public partial class Odonto_contas : Form
    {
        String rdado;
        public Odonto_contas(String Dado)
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            rdado = Dado;
            preencher();

            dataGridView.BorderStyle = BorderStyle.None;
            dataGridView.BackgroundColor = Color.White;

            dataGridView.EnableHeadersVisualStyles = false;
            dataGridView.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 108, 146);
            dataGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.BackgroundColor = Color.White;

            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 108, 146);
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            dataGridView2.BorderStyle = BorderStyle.None;
            dataGridView2.BackgroundColor = Color.White;

            dataGridView2.EnableHeadersVisualStyles = false;
            dataGridView2.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView2.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 108, 146);
            dataGridView2.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        }

        void preencher2()
        {
            string MyConnection = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True; convert zero datetime=true";
            MySqlConnection MyConn = new MySqlConnection(MyConnection);
            MyConn.Open();
            MySqlDataAdapter sqlda = new MySqlDataAdapter("SELECT FC_emissao, FC_vencimento, FC_pessoa, FC_desc, Concat('R$ ',REPLACE(REPLACE(REPLACE(Format(FC_totalp, 2), '.', '|'), ',', '.'), '|', ',')) FC_totalp,FC_Parcelas, Concat('R$ ',REPLACE(REPLACE(REPLACE(Format(FC_entrada, 2), '.', '|'), ',', '.'), '|', ',')) FC_entrada, FC_valor_item, FC_quant, FC_visivel  from odonto_ajrt.tb_fluxo_caixa WHERE FC_visivel = 1 and FC_saida is NULL OR FC_saida = 0 ORDER BY FC_emissao ASC;", MyConnection);
            DataTable dtbl = new DataTable();
            sqlda.Fill(dtbl);
            dataGridView2.AutoGenerateColumns = false;
            dataGridView2.DataSource = dtbl;

            MyConn.Close();
        }

        void preencher1()
        {
            string MyConnection = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True; convert zero datetime=true";
            MySqlConnection MyConn = new MySqlConnection(MyConnection);
            MyConn.Open();
            MySqlDataAdapter sqlda = new MySqlDataAdapter("SELECT FC_vencimento, FC_pessoa, FC_desc, Concat('R$ ',REPLACE(REPLACE(REPLACE(Format(FC_totalp, 2), '.', '|'), ',', '.'), '|', ',')) FC_totalp,FC_Parcelas, Concat('R$ ',REPLACE(REPLACE(REPLACE(Format(FC_saida, 2), '.', '|'), ',', '.'), '|', ',')) FC_saida, FC_valor_item, FC_quant, FC_visivel  from odonto_ajrt.tb_fluxo_caixa WHERE FC_visivel = 1 and FC_entrada is NULL OR FC_entrada = 0 ORDER BY FC_emissao ASC;", MyConnection);
            DataTable dtbl = new DataTable();
            sqlda.Fill(dtbl);
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dtbl;

            MyConn.Close();
        }

        void preencher()
        {
            string MyConnection = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True; convert zero datetime=true";
            MySqlConnection MyConn = new MySqlConnection(MyConnection);
            MyConn.Open();
            MySqlDataAdapter sqlda = new MySqlDataAdapter("SELECT FC_emissao, FC_vencimento, FC_pessoa, FC_desc, Concat('R$ ',REPLACE(REPLACE(REPLACE(Format(FC_totalp, 2), '.', '|'), ',', '.'), '|', ',')) FC_totalp,FC_Parcelas, Concat('R$ ',REPLACE(REPLACE(REPLACE(Format(FC_entrada, 2), '.', '|'), ',', '.'), '|', ',')) FC_entrada, Concat('R$ ',REPLACE(REPLACE(REPLACE(Format(FC_valor_item, 2), '.', '|'), ',', '.'), '|', ',')) FC_valor_item, FC_quant, FC_visivel, Concat('R$ ',REPLACE(REPLACE(REPLACE(Format(FC_saida, 2), '.', '|'), ',', '.'), '|', ',')) FC_saida  from odonto_ajrt.tb_fluxo_caixa WHERE FC_visivel = 1 ORDER BY FC_emissao ASC;", MyConnection);
            DataTable dtbl = new DataTable();
            sqlda.Fill(dtbl);
            dataGridView.AutoGenerateColumns = false;
            dataGridView.DataSource = dtbl;

            MyConn.Close();

            string Query = "SELECT Concat('R$ ',REPLACE(REPLACE(REPLACE(Format(SUM(FC_entrada), 2), '.', '|'), ',', '.'), '|', ',')) entrada, Concat('R$ ',REPLACE(REPLACE(REPLACE(Format(SUM(FC_saida), 2), '.', '|'), ',', '.'), '|', ',')) saida FROM tb_fluxo_caixa WHERE FC_visivel = 1;";
            MySqlConnection MyConn1 = new MySqlConnection(MyConnection);
            MySqlCommand MyCommand = new MySqlCommand(Query, MyConn1);
            MySqlDataReader MyReader;
            MyConn1.Open();
            MyReader = MyCommand.ExecuteReader();

            while (MyReader.Read())
            {
                    entradas.Text = MyReader.GetString("entrada");
                    saidas.Text = MyReader.GetString("saida");
            }
            MyConn1.Close();


            string Query2 = "SELECT SUM(FC_entrada) entrada, SUM(FC_saida) saida FROM tb_fluxo_caixa WHERE FC_visivel = 1;";
            MySqlConnection MyConn2 = new MySqlConnection(MyConnection);
            MySqlCommand MyCommand2 = new MySqlCommand(Query2, MyConn2);
            MySqlDataReader MyReader2;
            MyConn2.Open();
            MyReader2 = MyCommand2.ExecuteReader();

            decimal positivo;
            decimal negativo;

            while (MyReader2.Read())
            {
                positivo = MyReader2.GetDecimal("entrada");
                negativo = MyReader2.GetDecimal("saida");
                decimal resulta = positivo - negativo;
                resultado.Text = resulta.ToString("C2", CultureInfo.CurrentCulture);
            }//estou alterado 14/06
            MyConn2.Close();

        }

        private void ClearData2()
        {
            txt_cliente.Text = "";
            txt_emi.Text = DateTime.Now.ToString();
            txt_venc2.Text = DateTime.Now.ToString();
            txt_desc2.Text = "";
            txt_valor2.Text = "00,00";
            txt_quant2.Text = "0";
            txt_parc2.Text = "0";
        }

        private void ClearData1()
        {
            txt_fornecedor.Text = "";
            txt_venc1.Text = DateTime.Now.ToString();
            txt_desc1.Text = "";
            txt_valor1.Text = "00,00";
            txt_quant1.Text = "0";
            txt_parc1.Text = "0";
        }

        private void Minimizar_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void Menorizar_Click(object sender, EventArgs e)
        {
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Normal;
            this.Maximizar.Visible = true;
            this.Menorizar.Visible = false;
        }

        private void Maximizar_Click(object sender, EventArgs e)
        {
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
            this.Maximizar.Visible = false;
            this.Menorizar.Visible = true;
        }

        private void Fechar_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void BEsquerda_Click(object sender, EventArgs e)
        {
            main_odonto objFrmMain = new main_odonto(rdado);
            this.Hide();
            objFrmMain.Show();
        }

        private void Receber_Click(object sender, EventArgs e)
        {
            panel4.Visible = false;
            panel3.Visible = false;
            panel6.Visible = true;
            preencher2();
        }

        private void FCaixa_Click(object sender, EventArgs e)
        {
            preencher();
            panel4.Visible = false;
            panel3.Visible = true;
            panel6.Visible = false;
        }

        private void Pagar_Click(object sender, EventArgs e)
        {
            panel4.Visible = true;
            panel3.Visible = false;
            panel6.Visible = false;
            preencher1();
        }

        private void Cadastrar2_Click(object sender, EventArgs e)
        {
            if (txt_cliente.Text != "")
            {
                if (txt_emi.Value.Date > DateTime.Now)
                {
                    if (txt_venc2.Value.Date > DateTime.Now)
                    {
                        if (txt_desc2.Text != "")
                        {
                            if (txt_valor2.Text != "")
                            {
                                if (txt_parc2.Text != "" && txt_parc2.Text != "0")
                                {
                                    try
                                    {
                                        decimal valor = Convert.ToDecimal(txt_valor2.Text);
                                        decimal quantidade = Convert.ToDecimal(txt_quant2.Text);
                                        decimal parcelas = Convert.ToDecimal(txt_parc2.Text);
                                        decimal total = (valor * quantidade);
                                        decimal totalp = (total / parcelas);


                                        //This is my connection string i have assigned the database file address path  
                                        string MyConnection1 = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
                                        //This is my insert query in which i am taking input from the user through windows forms  
                                        string Query1 = "insert into tb_fluxo_caixa(FC_pessoa,FC_emissao,FC_vencimento,FC_desc,FC_valor_item,FC_parcelas,FC_quant,FC_totalp,FC_entrada,FC_situacao) values('" + this.txt_cliente.Text + "','" + this.txt_emi.Text + "','" + this.txt_venc2.Text + "','" + this.txt_desc2.Text + "','" + this.txt_valor2.Text + "','" + this.txt_parc2.Text + "','" + quantidade + "','" + totalp + "','" + total + "','Não');";
                                        //This is  MySqlConnection here i have created the object and pass my connection string.  
                                        MySqlConnection MyConn1 = new MySqlConnection(MyConnection1);
                                        //This is command class which will handle the query and connection object.  
                                        MySqlCommand MyCommand1 = new MySqlCommand(Query1, MyConn1);
                                        MySqlDataReader MyReader1;
                                        MyConn1.Open();
                                        MyReader1 = MyCommand1.ExecuteReader();     // Here our query will be executed and data saved into the database.  

                                        MessageBox.Show("Novo recebido cadatrado!!");
                                        while (MyReader1.Read())
                                        {
                                        }
                                        MyConn1.Close();

                                    }
                                    catch (Exception ex)
                                    {
                                        MessageBox.Show(ex.Message);
                                    }
                                    ClearData2();
                                    preencher2();
                                    Cadastrar2.Visible = true;
                                }
                                else { MessageBox.Show("Informe o número de parcelas!!"); }
                            }
                            else { MessageBox.Show("Informe um valor para o recebido!!"); }
                        }
                        else { MessageBox.Show("Informe uma descrição!!"); }
                    }
                    else { MessageBox.Show("Não é possivel cadastrar com uma data de vencimento ja expirada!!"); }
                }
                else { MessageBox.Show("Não é possivel cadastrar um recebido com uma data de emissão expirada!!"); }
            }
            else { MessageBox.Show("Informe o nome do cliente!!"); }
        }

        private void Alterar2_Click(object sender, EventArgs e)
        {
            if (txt_cliente.Text != "")
            {
                if (txt_emi.Value.Date > DateTime.Now)
                {
                    if (txt_venc2.Value.Date > DateTime.Now)
                    {
                        if (txt_desc2.Text != "")
                        {
                            if (txt_valor2.Text != "")
                            {
                                if (txt_parc2.Text != "" && txt_parc2.Text != "0")
                                {
                                    try
                                    {
                                        decimal valor = Convert.ToDecimal(txt_valor2.Text);
                                        decimal quantidade = Convert.ToDecimal(txt_quant2.Text);
                                        decimal parcelas = Convert.ToDecimal(txt_parc2.Text);
                                        decimal total = (valor * quantidade);
                                        decimal totalp = (total / parcelas);


                                        //This is my connection string i have assigned the database file address path  
                                        string MyConnection1 = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
                                        //This is my insert query in which i am taking input from the user through windows forms  
                                        string Query1 = "update tb_fluxo_caixa set FC_pessoa = '" + this.txt_cliente.Text + "', FC_emissao = '" + this.txt_emi.Text + "', FC_vencimento = '" + this.txt_venc2.Text + "', FC_desc = '" + this.txt_desc2.Text + "', FC_valor_item = '" + this.txt_valor2.Text + "', FC_quant = '" + this.txt_quant2.Text + "', FC_parcelas = '" + this.txt_parc2.Text + "', FC_totalp = '" + totalp + "', FC_entrada = '" + total + "', FC_situacao = 'não' where FC_id ='" + this.ID.Text + "'";
                                        //This is  MySqlConnection here i have created the object and pass my connection string.  
                                        MySqlConnection MyConn1 = new MySqlConnection(MyConnection1);
                                        //This is command class which will handle the query and connection object.  
                                        MySqlCommand MyCommand1 = new MySqlCommand(Query1, MyConn1);
                                        MySqlDataReader MyReader1;
                                        MyConn1.Open();
                                        MyReader1 = MyCommand1.ExecuteReader();     // Here our query will be executed and data saved into the database.  

                                        MessageBox.Show("Recebido atualizado!!");
                                        while (MyReader1.Read())
                                        {
                                        }
                                        MyConn1.Close();

                                    }
                                    catch (Exception ex)
                                    {
                                        MessageBox.Show(ex.Message);
                                    }
                                    ClearData2();
                                    preencher2();
                                    Cadastrar2.Visible = true;
                                }
                                else { MessageBox.Show("Informe o número de parcelas!!"); }
                            }
                            else { MessageBox.Show("Informe um valor para o recebido!!"); }
                        }
                        else { MessageBox.Show("Informe uma descrição!!"); }
                    }
                    else { MessageBox.Show("Não é possivel cadastrar com uma data de vencimento ja expirada!!"); }
                }
                else { MessageBox.Show("Não é possivel cadastrar um recebido com uma data de emissão expirada!!"); }
            }
            else { MessageBox.Show("Informe o nome do cliente!!"); }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_cliente.Text = dataGridView2.Rows[e.RowIndex].Cells[2].Value.ToString();
            txt_emi.Text = dataGridView2.Rows[e.RowIndex].Cells[0].Value.ToString();
            txt_venc2.Text = dataGridView2.Rows[e.RowIndex].Cells[1].Value.ToString();
            txt_desc2.Text = dataGridView2.Rows[e.RowIndex].Cells[3].Value.ToString();
            txt_valor2.Text = dataGridView2.Rows[e.RowIndex].Cells[4].Value.ToString();
            txt_quant2.Text = dataGridView2.Rows[e.RowIndex].Cells[5].Value.ToString();
            txt_parc2.Text = dataGridView2.Rows[e.RowIndex].Cells[7].Value.ToString();

            string MyConnection = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True; convert zero datetime=true";
            MySqlConnection MyConn = new MySqlConnection(MyConnection);
            string Query0 = "SELECT * from tb_fluxo_caixa;";
            MySqlCommand MyCommand = new MySqlCommand(Query0, MyConn);
            MySqlDataReader MyReader;
            MyConn.Open();
            MyReader = MyCommand.ExecuteReader();
            while (MyReader.Read()) //Coloca o ID do Funcionario no Label_id
            {
                string Idcaixa = MyReader.GetString("FC_id");
                ID.Text = Idcaixa;
            }
            MyConn.Close();

            Cadastrar2.Visible = false;
        }

        private void Excluir2_Click(object sender, EventArgs e)
        {
            string MyConnection1 = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
            string Query1 = "update tb_fluxo_caixa set FC_visivel = 0 where FC_id = " + ID.Text + "";
            MySqlConnection MyConn1 = new MySqlConnection(MyConnection1);
            MySqlCommand MyCommand1 = new MySqlCommand(Query1, MyConn1);
            MySqlDataReader MyReader1;
            MyConn1.Open();
            MyReader1 = MyCommand1.ExecuteReader();

            MessageBox.Show("Dados excluidos");
            while (MyReader1.Read())
            {
            }
            MyConn1.Close();
            ClearData2();
            preencher2();
            Cadastrar2.Visible = true;
        }

        private void Pesquisa_TextChanged(object sender, EventArgs e)
        {
            if (Pesquisa.Text != "")
            {
                string MyConnection = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True; convert zero datetime=true";
                MySqlConnection MyConn = new MySqlConnection(MyConnection);
                MyConn.Open();
                MySqlDataAdapter sqlda = new MySqlDataAdapter("SELECT FC_emissao, FC_vencimento, FC_pessoa, FC_desc, Concat('R$ ',REPLACE(REPLACE(REPLACE(Format(FC_totalp, 2), '.', '|'), ',', '.'), '|', ',')) FC_totalp,FC_Parcelas, Concat('R$ ',REPLACE(REPLACE(REPLACE(Format(FC_entrada, 2), '.', '|'), ',', '.'), '|', ',')) FC_entrada, Concat('R$ ',REPLACE(REPLACE(REPLACE(Format(FC_valor_item, 2), '.', '|'), ',', '.'), '|', ',')) FC_valor_item, FC_quant, FC_visivel, Concat('R$ ',REPLACE(REPLACE(REPLACE(Format(FC_saida, 2), '.', '|'), ',', '.'), '|', ',')) FC_saida from tb_fluxo_caixa where FC_pessoa like '" + Pesquisa.Text + "%' ORDER BY FC_pessoa ASC;", MyConnection);
                DataTable dtbl = new DataTable();
                sqlda.Fill(dtbl);
                dataGridView.AutoGenerateColumns = false;
                dataGridView.DataSource = dtbl;

                MyConn.Close();
            }
            else { preencher(); }
        }

        private void Cadastrar1_Click(object sender, EventArgs e)
        {
            if (txt_fornecedor.Text != "")
            {
                if (txt_venc1.Value.Date > DateTime.Now)
                {
                    if (txt_desc1.Text != "")
                    {
                        if (txt_valor1.Text != "")
                        {
                            if (txt_parc1.Text != "" && txt_parc1.Text != "0")
                            {
                                try
                                {
                                    decimal valor = Convert.ToDecimal(txt_valor1.Text);
                                    decimal quantidade = Convert.ToDecimal(txt_quant1.Text);
                                    decimal parcelas = Convert.ToDecimal(txt_parc1.Text);
                                    decimal total = (valor * quantidade);
                                    decimal totalp = (total / parcelas);


                                    //This is my connection string i have assigned the database file address path  
                                    string MyConnection1 = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
                                    //This is my insert query in which i am taking input from the user through windows forms  
                                    string Query1 = "insert into tb_fluxo_caixa(FC_pessoa,FC_vencimento,FC_desc,FC_valor_item,FC_parcelas,FC_quant,FC_totalp,FC_saida,FC_situacao) values('" + this.txt_fornecedor.Text + "','" + this.txt_venc1.Text + "','" + this.txt_desc1.Text + "','" + this.txt_valor1.Text + "','" + this.txt_parc1.Text + "','" + quantidade + "','" + totalp + "','" + total + "','Não');";
                                    //This is  MySqlConnection here i have created the object and pass my connection string.  
                                    MySqlConnection MyConn1 = new MySqlConnection(MyConnection1);
                                    //This is command class which will handle the query and connection object.  
                                    MySqlCommand MyCommand1 = new MySqlCommand(Query1, MyConn1);
                                    MySqlDataReader MyReader1;
                                    MyConn1.Open();
                                    MyReader1 = MyCommand1.ExecuteReader();     // Here our query will be executed and data saved into the database.  

                                    MessageBox.Show("Nova saída cadatrada!!");
                                    while (MyReader1.Read())
                                    {
                                    }
                                    MyConn1.Close();

                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show(ex.Message);
                                }
                                ClearData1();
                                preencher1();
                                Cadastrar1.Visible = true;
                            }
                            else { MessageBox.Show("Informe o número de parcelas!!"); }
                        }
                        else { MessageBox.Show("Informe um valor para o recebido!!"); }
                    }
                    else { MessageBox.Show("Informe uma descrição!!"); }
                }
                else { MessageBox.Show("Não é possivel cadastrar com uma data de vencimento ja expirada!!"); }
            }
            else { MessageBox.Show("Informe o nome do cliente!!"); }
        }

        private void Alterar1_Click(object sender, EventArgs e)
        {
            if (txt_fornecedor.Text != "")
            {
                if (txt_venc1.Value.Date > DateTime.Now)
                {
                    if (txt_desc1.Text != "")
                    {
                        if (txt_valor1.Text != "")
                        {
                            if (txt_parc1.Text != "" && txt_parc1.Text != "0")
                            {
                                try
                                {
                                    decimal valor = Convert.ToDecimal(txt_valor1.Text);
                                    decimal quantidade = Convert.ToDecimal(txt_quant1.Text);
                                    decimal parcelas = Convert.ToDecimal(txt_parc1.Text);
                                    decimal total = (valor * quantidade);
                                    decimal totalp = (total / parcelas);


                                    //This is my connection string i have assigned the database file address path  
                                    string MyConnection1 = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
                                    //This is my insert query in which i am taking input from the user through windows forms  
                                    string Query1 = "update tb_fluxo_caixa set FC_pessoa = '" + this.txt_fornecedor.Text + "', FC_vencimento = '" + this.txt_venc1.Text + "', FC_desc = '" + this.txt_desc1.Text + "', FC_valor_item = '" + this.txt_valor1.Text + "', FC_quant = '" + this.txt_quant1.Text + "', FC_parcelas = '" + this.txt_parc1.Text + "', FC_totalp = '" + totalp + "', FC_saida = '" + total + "', FC_situacao = 'não' where FC_id ='" + this.ID1.Text + "'";
                                    //This is  MySqlConnection here i have created the object and pass my connection string.  
                                    MySqlConnection MyConn1 = new MySqlConnection(MyConnection1);
                                    //This is command class which will handle the query and connection object.  
                                    MySqlCommand MyCommand1 = new MySqlCommand(Query1, MyConn1);
                                    MySqlDataReader MyReader1;
                                    MyConn1.Open();
                                    MyReader1 = MyCommand1.ExecuteReader();     // Here our query will be executed and data saved into the database.  

                                    MessageBox.Show("Saídas atualizadas!!");
                                    while (MyReader1.Read())
                                    {
                                    }
                                    MyConn1.Close();

                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show(ex.Message);
                                }
                                ClearData1();
                                preencher1();
                                Cadastrar1.Visible = true;
                            }
                            else { MessageBox.Show("Informe o número de parcelas!!"); }
                        }
                        else { MessageBox.Show("Informe um valor para o recebido!!"); }
                    }
                    else { MessageBox.Show("Informe uma descrição!!"); }
                }
                else { MessageBox.Show("Não é possivel cadastrar com uma data de vencimento ja expirada!!"); }
            }
            else { MessageBox.Show("Informe o nome do cliente!!"); }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_fornecedor.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            //txt_emi.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            txt_venc1.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            txt_desc1.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            txt_valor1.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
            txt_quant1.Text = dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
            txt_parc1.Text = dataGridView1.Rows[e.RowIndex].Cells[8].Value.ToString();

            string MyConnection = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True; convert zero datetime=true";
            MySqlConnection MyConn = new MySqlConnection(MyConnection);
            string Query0 = "SELECT * from tb_fluxo_caixa;";
            MySqlCommand MyCommand = new MySqlCommand(Query0, MyConn);
            MySqlDataReader MyReader;
            MyConn.Open();
            MyReader = MyCommand.ExecuteReader();
            while (MyReader.Read()) //Coloca o ID do Funcionario no Label_id
            {
                string Idcaixa = MyReader.GetString("FC_id");
                ID1.Text = Idcaixa;
            }
            MyConn.Close();

            Cadastrar1.Visible = false;
        }

        private void Excluir1_Click(object sender, EventArgs e)
        {
            string MyConnection1 = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
            string Query1 = "update tb_fluxo_caixa set FC_visivel = 0 where FC_id = " + ID1.Text + "";
            MySqlConnection MyConn1 = new MySqlConnection(MyConnection1);
            MySqlCommand MyCommand1 = new MySqlCommand(Query1, MyConn1);
            MySqlDataReader MyReader1;
            MyConn1.Open();
            MyReader1 = MyCommand1.ExecuteReader();

            MessageBox.Show("Dados excluidos");
            while (MyReader1.Read())
            {
            }
            MyConn1.Close();
            ClearData1();
            preencher1();
            Cadastrar1.Visible = true;
        }
    }
}
