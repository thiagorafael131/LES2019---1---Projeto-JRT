﻿namespace Odonto_AJRT
{
    partial class Odonto_estoque
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Odonto_estoque));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Maximizar = new System.Windows.Forms.PictureBox();
            this.Fechar = new System.Windows.Forms.PictureBox();
            this.Menorizar = new System.Windows.Forms.PictureBox();
            this.Minimizar = new System.Windows.Forms.PictureBox();
            this.BEsquerda = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_referencia = new System.Windows.Forms.TextBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_desc = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Validade = new System.Windows.Forms.DateTimePicker();
            this.label18 = new System.Windows.Forms.Label();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_categoria = new System.Windows.Forms.TextBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_p_uni = new System.Windows.Forms.TextBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_marca = new System.Windows.Forms.TextBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_unidade = new System.Windows.Forms.TextBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_quantidade = new System.Windows.Forms.TextBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_p_total = new System.Windows.Forms.TextBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.Registrar = new JThinButton.JThinButton();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_fornecedor = new System.Windows.Forms.TextBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.entrega = new System.Windows.Forms.DateTimePicker();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.Estoque_referencia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Estoque_desc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Estoque_marca = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Estoque_categoria = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Estoque_p_unidade = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Estoque_validade = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Estoque_unidade = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Estoque_quantidade = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Estoque_p_total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Estoque_fornecedor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Estoque_entrega = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Editar = new JThinButton.JThinButton();
            this.Excluir = new JThinButton.JThinButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.Pesquisa = new System.Windows.Forms.TextBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.label15 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.jDragControl1 = new JDragControl.JDragControl(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Maximizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Fechar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Menorizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minimizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BEsquerda)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.Maximizar);
            this.panel1.Controls.Add(this.Fechar);
            this.panel1.Controls.Add(this.Menorizar);
            this.panel1.Controls.Add(this.Minimizar);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(831, 23);
            this.panel1.TabIndex = 2;
            // 
            // Maximizar
            // 
            this.Maximizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Maximizar.Image = ((System.Drawing.Image)(resources.GetObject("Maximizar.Image")));
            this.Maximizar.Location = new System.Drawing.Point(804, 6);
            this.Maximizar.Name = "Maximizar";
            this.Maximizar.Size = new System.Drawing.Size(10, 10);
            this.Maximizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Maximizar.TabIndex = 146;
            this.Maximizar.TabStop = false;
            this.Maximizar.Visible = false;
            this.Maximizar.Click += new System.EventHandler(this.Maximizar_Click);
            // 
            // Fechar
            // 
            this.Fechar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Fechar.Image = ((System.Drawing.Image)(resources.GetObject("Fechar.Image")));
            this.Fechar.Location = new System.Drawing.Point(818, 6);
            this.Fechar.Name = "Fechar";
            this.Fechar.Size = new System.Drawing.Size(10, 10);
            this.Fechar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Fechar.TabIndex = 148;
            this.Fechar.TabStop = false;
            this.Fechar.Click += new System.EventHandler(this.Fechar_Click);
            // 
            // Menorizar
            // 
            this.Menorizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Menorizar.Image = ((System.Drawing.Image)(resources.GetObject("Menorizar.Image")));
            this.Menorizar.Location = new System.Drawing.Point(804, 6);
            this.Menorizar.Name = "Menorizar";
            this.Menorizar.Size = new System.Drawing.Size(10, 10);
            this.Menorizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Menorizar.TabIndex = 147;
            this.Menorizar.TabStop = false;
            this.Menorizar.Click += new System.EventHandler(this.Menorizar_Click);
            // 
            // Minimizar
            // 
            this.Minimizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Minimizar.Image = ((System.Drawing.Image)(resources.GetObject("Minimizar.Image")));
            this.Minimizar.Location = new System.Drawing.Point(788, 6);
            this.Minimizar.Name = "Minimizar";
            this.Minimizar.Size = new System.Drawing.Size(10, 10);
            this.Minimizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Minimizar.TabIndex = 145;
            this.Minimizar.TabStop = false;
            this.Minimizar.Click += new System.EventHandler(this.Minimizar_Click);
            // 
            // BEsquerda
            // 
            this.BEsquerda.BackColor = System.Drawing.Color.Transparent;
            this.BEsquerda.Image = ((System.Drawing.Image)(resources.GetObject("BEsquerda.Image")));
            this.BEsquerda.Location = new System.Drawing.Point(12, 36);
            this.BEsquerda.Name = "BEsquerda";
            this.BEsquerda.Size = new System.Drawing.Size(32, 41);
            this.BEsquerda.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BEsquerda.TabIndex = 3;
            this.BEsquerda.TabStop = false;
            this.BEsquerda.Click += new System.EventHandler(this.BEsquerda_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(58, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(250, 110);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label13.Location = new System.Drawing.Point(44, 217);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(98, 21);
            this.label13.TabIndex = 68;
            this.label13.Text = "Referência:";
            // 
            // txt_referencia
            // 
            this.txt_referencia.BackColor = System.Drawing.Color.White;
            this.txt_referencia.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_referencia.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_referencia.Location = new System.Drawing.Point(51, 248);
            this.txt_referencia.Name = "txt_referencia";
            this.txt_referencia.Size = new System.Drawing.Size(147, 20);
            this.txt_referencia.TabIndex = 1;
            this.txt_referencia.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox14.Image")));
            this.pictureBox14.Location = new System.Drawing.Point(35, 241);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(179, 34);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox14.TabIndex = 69;
            this.pictureBox14.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label1.Location = new System.Drawing.Point(43, 178);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(196, 28);
            this.label1.TabIndex = 128;
            this.label1.Text = "Cadastrar Item:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label2.Location = new System.Drawing.Point(232, 217);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 21);
            this.label2.TabIndex = 130;
            this.label2.Text = "Descrição:";
            // 
            // txt_desc
            // 
            this.txt_desc.BackColor = System.Drawing.Color.White;
            this.txt_desc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_desc.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_desc.Location = new System.Drawing.Point(236, 248);
            this.txt_desc.Name = "txt_desc";
            this.txt_desc.Size = new System.Drawing.Size(147, 20);
            this.txt_desc.TabIndex = 2;
            this.txt_desc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(220, 241);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(179, 34);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 131;
            this.pictureBox2.TabStop = false;
            // 
            // Validade
            // 
            this.Validade.CalendarFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Validade.CalendarMonthBackground = System.Drawing.Color.White;
            this.Validade.CustomFormat = "yyyy-MM-dd";
            this.Validade.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Validade.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Validade.Location = new System.Drawing.Point(421, 305);
            this.Validade.Name = "Validade";
            this.Validade.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Validade.Size = new System.Drawing.Size(147, 27);
            this.Validade.TabIndex = 6;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label18.Location = new System.Drawing.Point(416, 217);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(66, 21);
            this.label18.TabIndex = 133;
            this.label18.Text = "Marca:";
            // 
            // pictureBox20
            // 
            this.pictureBox20.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox20.Image")));
            this.pictureBox20.Location = new System.Drawing.Point(405, 241);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(179, 34);
            this.pictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox20.TabIndex = 134;
            this.pictureBox20.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label3.Location = new System.Drawing.Point(44, 277);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 21);
            this.label3.TabIndex = 136;
            this.label3.Text = "Categoria:";
            // 
            // txt_categoria
            // 
            this.txt_categoria.BackColor = System.Drawing.Color.White;
            this.txt_categoria.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_categoria.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_categoria.Location = new System.Drawing.Point(51, 308);
            this.txt_categoria.Name = "txt_categoria";
            this.txt_categoria.Size = new System.Drawing.Size(147, 20);
            this.txt_categoria.TabIndex = 4;
            this.txt_categoria.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(35, 301);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(179, 34);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 137;
            this.pictureBox3.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label4.Location = new System.Drawing.Point(232, 277);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 21);
            this.label4.TabIndex = 139;
            this.label4.Text = "Preço Unitário:";
            // 
            // txt_p_uni
            // 
            this.txt_p_uni.BackColor = System.Drawing.Color.White;
            this.txt_p_uni.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_p_uni.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_p_uni.Location = new System.Drawing.Point(236, 308);
            this.txt_p_uni.Name = "txt_p_uni";
            this.txt_p_uni.Size = new System.Drawing.Size(147, 20);
            this.txt_p_uni.TabIndex = 5;
            this.txt_p_uni.Text = "0";
            this.txt_p_uni.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_p_uni.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_p_uni_KeyPress);
            this.txt_p_uni.Leave += new System.EventHandler(this.txt_p_uni_Leave);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(220, 301);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(179, 34);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox4.TabIndex = 140;
            this.pictureBox4.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label5.Location = new System.Drawing.Point(416, 277);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 21);
            this.label5.TabIndex = 142;
            this.label5.Text = "Validade:";
            // 
            // txt_marca
            // 
            this.txt_marca.BackColor = System.Drawing.Color.White;
            this.txt_marca.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_marca.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_marca.Location = new System.Drawing.Point(421, 248);
            this.txt_marca.Name = "txt_marca";
            this.txt_marca.Size = new System.Drawing.Size(147, 20);
            this.txt_marca.TabIndex = 3;
            this.txt_marca.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(405, 301);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(179, 34);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox5.TabIndex = 143;
            this.pictureBox5.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label6.Location = new System.Drawing.Point(44, 337);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 21);
            this.label6.TabIndex = 145;
            this.label6.Text = "Unidade:";
            // 
            // txt_unidade
            // 
            this.txt_unidade.BackColor = System.Drawing.Color.White;
            this.txt_unidade.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_unidade.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_unidade.Location = new System.Drawing.Point(51, 368);
            this.txt_unidade.Name = "txt_unidade";
            this.txt_unidade.Size = new System.Drawing.Size(147, 20);
            this.txt_unidade.TabIndex = 7;
            this.txt_unidade.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_unidade.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_unidade_KeyPress);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(35, 361);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(179, 34);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox6.TabIndex = 146;
            this.pictureBox6.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label7.Location = new System.Drawing.Point(232, 337);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(112, 21);
            this.label7.TabIndex = 148;
            this.label7.Text = "Quantidade:";
            // 
            // txt_quantidade
            // 
            this.txt_quantidade.BackColor = System.Drawing.Color.White;
            this.txt_quantidade.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_quantidade.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_quantidade.Location = new System.Drawing.Point(236, 368);
            this.txt_quantidade.Name = "txt_quantidade";
            this.txt_quantidade.Size = new System.Drawing.Size(147, 20);
            this.txt_quantidade.TabIndex = 8;
            this.txt_quantidade.Text = "0";
            this.txt_quantidade.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_quantidade.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_quantidade_KeyPress);
            this.txt_quantidade.Leave += new System.EventHandler(this.txt_quantidade_Leave);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(220, 361);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(179, 34);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox7.TabIndex = 149;
            this.pictureBox7.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label8.Location = new System.Drawing.Point(416, 337);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 21);
            this.label8.TabIndex = 151;
            this.label8.Text = "Preço Total:";
            // 
            // txt_p_total
            // 
            this.txt_p_total.BackColor = System.Drawing.Color.White;
            this.txt_p_total.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_p_total.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_p_total.Location = new System.Drawing.Point(421, 368);
            this.txt_p_total.Name = "txt_p_total";
            this.txt_p_total.Size = new System.Drawing.Size(147, 20);
            this.txt_p_total.TabIndex = 9;
            this.txt_p_total.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(405, 361);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(179, 34);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox8.TabIndex = 152;
            this.pictureBox8.TabStop = false;
            // 
            // Registrar
            // 
            this.Registrar.BackColor = System.Drawing.Color.Transparent;
            this.Registrar.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Registrar.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Registrar.BorderRadius = 12;
            this.Registrar.ButtonText = "Cadastrar Item";
            this.Registrar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Registrar.Font_Size = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Registrar.ForeColors = System.Drawing.Color.White;
            this.Registrar.HoverBackground = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Registrar.HoverBorder = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Registrar.HoverFontColor = System.Drawing.Color.White;
            this.Registrar.LineThickness = 2;
            this.Registrar.Location = new System.Drawing.Point(611, 241);
            this.Registrar.Margin = new System.Windows.Forms.Padding(4);
            this.Registrar.Name = "Registrar";
            this.Registrar.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Registrar.Size = new System.Drawing.Size(179, 33);
            this.Registrar.TabIndex = 12;
            this.Registrar.Click += new System.EventHandler(this.Registrar_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label9.Location = new System.Drawing.Point(44, 399);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(99, 21);
            this.label9.TabIndex = 155;
            this.label9.Text = "Fornecedor";
            // 
            // txt_fornecedor
            // 
            this.txt_fornecedor.BackColor = System.Drawing.Color.White;
            this.txt_fornecedor.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_fornecedor.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_fornecedor.Location = new System.Drawing.Point(51, 430);
            this.txt_fornecedor.Name = "txt_fornecedor";
            this.txt_fornecedor.Size = new System.Drawing.Size(147, 20);
            this.txt_fornecedor.TabIndex = 10;
            this.txt_fornecedor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(35, 423);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(179, 34);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox9.TabIndex = 156;
            this.pictureBox9.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label10.Location = new System.Drawing.Point(232, 399);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(149, 21);
            this.label10.TabIndex = 158;
            this.label10.Text = "Data da entrega:";
            // 
            // entrega
            // 
            this.entrega.CalendarFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.entrega.CalendarMonthBackground = System.Drawing.Color.White;
            this.entrega.CustomFormat = "yyyy-MM-dd";
            this.entrega.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.entrega.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.entrega.Location = new System.Drawing.Point(236, 427);
            this.entrega.Name = "entrega";
            this.entrega.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.entrega.Size = new System.Drawing.Size(147, 27);
            this.entrega.TabIndex = 11;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(220, 423);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(179, 34);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox10.TabIndex = 159;
            this.pictureBox10.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label11.Location = new System.Drawing.Point(43, 493);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(222, 28);
            this.label11.TabIndex = 160;
            this.label11.Text = "Itens em Estoque:";
            // 
            // dataGridView
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.dataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Estoque_referencia,
            this.Estoque_desc,
            this.Estoque_marca,
            this.Estoque_categoria,
            this.Estoque_p_unidade,
            this.Estoque_validade,
            this.Estoque_unidade,
            this.Estoque_quantidade,
            this.Estoque_p_total,
            this.Estoque_fornecedor,
            this.Estoque_entrega});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.dataGridView.Location = new System.Drawing.Point(12, 566);
            this.dataGridView.Name = "dataGridView";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.dataGridView.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridView.Size = new System.Drawing.Size(807, 150);
            this.dataGridView.TabIndex = 161;
            this.dataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_CellContentClick);
            // 
            // Estoque_referencia
            // 
            this.Estoque_referencia.DataPropertyName = "Estoque_referencia";
            this.Estoque_referencia.HeaderText = "Referência";
            this.Estoque_referencia.Name = "Estoque_referencia";
            this.Estoque_referencia.Width = 101;
            // 
            // Estoque_desc
            // 
            this.Estoque_desc.DataPropertyName = "Estoque_desc";
            this.Estoque_desc.HeaderText = "Descrição";
            this.Estoque_desc.Name = "Estoque_desc";
            this.Estoque_desc.Width = 97;
            // 
            // Estoque_marca
            // 
            this.Estoque_marca.DataPropertyName = "Estoque_marca";
            this.Estoque_marca.HeaderText = "Marca";
            this.Estoque_marca.Name = "Estoque_marca";
            this.Estoque_marca.Width = 74;
            // 
            // Estoque_categoria
            // 
            this.Estoque_categoria.DataPropertyName = "Estoque_categoria";
            this.Estoque_categoria.HeaderText = "Categoria";
            this.Estoque_categoria.Name = "Estoque_categoria";
            // 
            // Estoque_p_unidade
            // 
            this.Estoque_p_unidade.DataPropertyName = "Estoque_p_unidade";
            this.Estoque_p_unidade.HeaderText = "Preço Unitário";
            this.Estoque_p_unidade.Name = "Estoque_p_unidade";
            this.Estoque_p_unidade.Width = 123;
            // 
            // Estoque_validade
            // 
            this.Estoque_validade.DataPropertyName = "Estoque_validade";
            this.Estoque_validade.HeaderText = "Validade";
            this.Estoque_validade.Name = "Estoque_validade";
            this.Estoque_validade.Width = 92;
            // 
            // Estoque_unidade
            // 
            this.Estoque_unidade.DataPropertyName = "Estoque_unidade";
            this.Estoque_unidade.HeaderText = "Unidade";
            this.Estoque_unidade.Name = "Estoque_unidade";
            this.Estoque_unidade.Width = 87;
            // 
            // Estoque_quantidade
            // 
            this.Estoque_quantidade.DataPropertyName = "Estoque_quantidade";
            this.Estoque_quantidade.HeaderText = "Quantidade";
            this.Estoque_quantidade.Name = "Estoque_quantidade";
            this.Estoque_quantidade.Width = 112;
            // 
            // Estoque_p_total
            // 
            this.Estoque_p_total.DataPropertyName = "Estoque_p_total";
            this.Estoque_p_total.HeaderText = "Preço Total";
            this.Estoque_p_total.Name = "Estoque_p_total";
            this.Estoque_p_total.Width = 105;
            // 
            // Estoque_fornecedor
            // 
            this.Estoque_fornecedor.DataPropertyName = "Estoque_fornecedor";
            this.Estoque_fornecedor.HeaderText = "Fornecedor";
            this.Estoque_fornecedor.Name = "Estoque_fornecedor";
            this.Estoque_fornecedor.Width = 106;
            // 
            // Estoque_entrega
            // 
            this.Estoque_entrega.DataPropertyName = "Estoque_entrega";
            this.Estoque_entrega.HeaderText = "Data de Entraga";
            this.Estoque_entrega.Name = "Estoque_entrega";
            this.Estoque_entrega.Width = 142;
            // 
            // Editar
            // 
            this.Editar.BackColor = System.Drawing.Color.Transparent;
            this.Editar.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Editar.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Editar.BorderRadius = 12;
            this.Editar.ButtonText = "Editar Item";
            this.Editar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Editar.Font_Size = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Editar.ForeColors = System.Drawing.Color.White;
            this.Editar.HoverBackground = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Editar.HoverBorder = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Editar.HoverFontColor = System.Drawing.Color.White;
            this.Editar.LineThickness = 2;
            this.Editar.Location = new System.Drawing.Point(611, 301);
            this.Editar.Margin = new System.Windows.Forms.Padding(4);
            this.Editar.Name = "Editar";
            this.Editar.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Editar.Size = new System.Drawing.Size(179, 33);
            this.Editar.TabIndex = 162;
            this.Editar.Click += new System.EventHandler(this.Editar_Click);
            // 
            // Excluir
            // 
            this.Excluir.BackColor = System.Drawing.Color.Transparent;
            this.Excluir.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Excluir.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Excluir.BorderRadius = 12;
            this.Excluir.ButtonText = "Excluir Item";
            this.Excluir.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Excluir.Font_Size = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Excluir.ForeColors = System.Drawing.Color.White;
            this.Excluir.HoverBackground = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Excluir.HoverBorder = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Excluir.HoverFontColor = System.Drawing.Color.White;
            this.Excluir.LineThickness = 2;
            this.Excluir.Location = new System.Drawing.Point(611, 361);
            this.Excluir.Margin = new System.Windows.Forms.Padding(4);
            this.Excluir.Name = "Excluir";
            this.Excluir.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Excluir.Size = new System.Drawing.Size(179, 33);
            this.Excluir.TabIndex = 163;
            this.Excluir.Click += new System.EventHandler(this.Excluir_Click);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.BEsquerda);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Location = new System.Drawing.Point(0, 22);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(831, 153);
            this.panel2.TabIndex = 164;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label12.Location = new System.Drawing.Point(314, 74);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(141, 38);
            this.label12.TabIndex = 165;
            this.label12.Text = "Estoque";
            // 
            // Pesquisa
            // 
            this.Pesquisa.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.Pesquisa.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.Pesquisa.BackColor = System.Drawing.Color.White;
            this.Pesquisa.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Pesquisa.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pesquisa.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.Pesquisa.Location = new System.Drawing.Point(223, 531);
            this.Pesquisa.Name = "Pesquisa";
            this.Pesquisa.Size = new System.Drawing.Size(147, 20);
            this.Pesquisa.TabIndex = 167;
            this.Pesquisa.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Pesquisa.TextChanged += new System.EventHandler(this.Pesquisa_TextChanged);
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(207, 524);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(179, 34);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox11.TabIndex = 166;
            this.pictureBox11.TabStop = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label15.Location = new System.Drawing.Point(44, 531);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(164, 21);
            this.label15.TabIndex = 165;
            this.label15.Text = "Referência do Item:";
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.panel3.Location = new System.Drawing.Point(14, 489);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(801, 1);
            this.panel3.TabIndex = 168;
            // 
            // jDragControl1
            // 
            this.jDragControl1.GetForm = this;
            this.jDragControl1.TargetControl = this.panel1;
            // 
            // Odonto_estoque
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(831, 728);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.Pesquisa);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.Excluir);
            this.Controls.Add(this.Editar);
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.entrega);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txt_fornecedor);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.Registrar);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txt_p_total);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_quantidade);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_unidade);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_marca);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_p_uni);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_categoria);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.Validade);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.pictureBox20);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_desc);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txt_referencia);
            this.Controls.Add(this.pictureBox14);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Odonto_estoque";
            this.Text = "Odonto_estoque";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Maximizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Fechar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Menorizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minimizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BEsquerda)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox BEsquerda;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_referencia;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_desc;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.DateTimePicker Validade;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_categoria;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_p_uni;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_marca;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_unidade;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_quantidade;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_p_total;
        private System.Windows.Forms.PictureBox pictureBox8;
        private JThinButton.JThinButton Registrar;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_fornecedor;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker entrega;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn Estoque_referencia;
        private System.Windows.Forms.DataGridViewTextBoxColumn Estoque_desc;
        private System.Windows.Forms.DataGridViewTextBoxColumn Estoque_marca;
        private System.Windows.Forms.DataGridViewTextBoxColumn Estoque_categoria;
        private System.Windows.Forms.DataGridViewTextBoxColumn Estoque_p_unidade;
        private System.Windows.Forms.DataGridViewTextBoxColumn Estoque_validade;
        private System.Windows.Forms.DataGridViewTextBoxColumn Estoque_unidade;
        private System.Windows.Forms.DataGridViewTextBoxColumn Estoque_quantidade;
        private System.Windows.Forms.DataGridViewTextBoxColumn Estoque_p_total;
        private System.Windows.Forms.DataGridViewTextBoxColumn Estoque_fornecedor;
        private System.Windows.Forms.DataGridViewTextBoxColumn Estoque_entrega;
        private JThinButton.JThinButton Editar;
        private JThinButton.JThinButton Excluir;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox Pesquisa;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox Maximizar;
        private System.Windows.Forms.PictureBox Fechar;
        private System.Windows.Forms.PictureBox Menorizar;
        private System.Windows.Forms.PictureBox Minimizar;
        private JDragControl.JDragControl jDragControl1;
    }
}