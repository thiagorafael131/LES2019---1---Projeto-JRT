﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Odonto_AJRT
{
    public partial class Odonto_financeiro : Form
    {
        String rdado;
        public Odonto_financeiro(String Dado)
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            rdado = Dado;

            dataGridView_func.BorderStyle = BorderStyle.None;
            dataGridView_func.BackgroundColor = Color.White;

            dataGridView_func.EnableHeadersVisualStyles = false;
            dataGridView_func.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView_func.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 108, 146);
            dataGridView_func.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            dataGridView_consu.BorderStyle = BorderStyle.None;
            dataGridView_consu.BackgroundColor = Color.White;

            dataGridView_consu.EnableHeadersVisualStyles = false;
            dataGridView_consu.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView_consu.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 108, 146);
            dataGridView_consu.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            dataGridView_esto.BorderStyle = BorderStyle.None;
            dataGridView_esto.BackgroundColor = Color.White;

            dataGridView_esto.EnableHeadersVisualStyles = false;
            dataGridView_esto.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView_esto.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 108, 146);
            dataGridView_esto.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        }

        private void Fechar_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void Maximizar_Click(object sender, EventArgs e)
        {
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
            this.Maximizar.Visible = false;
            this.Menorizar.Visible = true;
        }

        private void Menorizar_Click(object sender, EventArgs e)
        {
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Normal;
            this.Maximizar.Visible = true;
            this.Menorizar.Visible = false;
        }

        private void Minimizar_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void BEsquerda_Click(object sender, EventArgs e)
        {
            main_odonto objFrmMain = new main_odonto(rdado);
            this.Hide();
            objFrmMain.Show();
        }

        public void Pesquisar(string Query, string selecao)
        {
            string MyConnection = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True; convert zero datetime=true";
            MySqlConnection MyConn = new MySqlConnection(MyConnection);
            MySqlCommand MyCommand1 = new MySqlCommand(Query, MyConn);
            MySqlDataReader MyReader1;
            MyConn.Open();
            MyReader1 = MyCommand1.ExecuteReader();


            MySqlDataAdapter sqlda = new MySqlDataAdapter(Query, MyConnection);
            DataTable dtbl = new DataTable();
            sqlda.Fill(dtbl);
            if (selecao == "Funcionário")
            {
                dataGridView_func.AutoGenerateColumns = false;
                dataGridView_func.DataSource = dtbl;
                dataGridView_func.Visible = true;
                dataGridView_consu.Visible = false;
                dataGridView_esto.Visible = false;

            }
            else if (selecao == "Consulta")
            {
                dataGridView_consu.AutoGenerateColumns = false;
                dataGridView_consu.DataSource = dtbl;
                dataGridView_func.Visible = false;
                dataGridView_consu.Visible = true;
                dataGridView_esto.Visible = false;
            }
            else if (selecao == "Estoque")
            {
                dataGridView_esto.AutoGenerateColumns = false;
                dataGridView_esto.DataSource = dtbl;
                dataGridView_func.Visible = false;
                dataGridView_consu.Visible = false;
                dataGridView_esto.Visible = true;

            }
            MyConn.Close();

        }

        private void comboBox_nome_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selecao = ((ComboBox)sender).SelectedItem.ToString();
            if (selecao == "Funcionário")
            {
                string Funcionario = "select Fun_id, concat(Fun_nome,' ',Fun_sobrenome) Funcionario, Fun_sal from odonto_ajrt.tb_funcionario;";
                Pesquisar(Funcionario, selecao);
            }
            else if (selecao == "Consulta")
            {
                string Consulta = "select Con_id,Con_tipo,Con_data,Con_preco from tb_consulta;";
                Pesquisar(Consulta, selecao);
            }
            else if (selecao == "Estoque")
            {
                string Estoque = "select Estoque_id, Estoque_desc, Estoque_p_unidade, Estoque_quantidade, Estoque_p_total from odonto_ajrt.tb_estoque;";
                Pesquisar(Estoque, selecao);
            }
        }
    }
}
