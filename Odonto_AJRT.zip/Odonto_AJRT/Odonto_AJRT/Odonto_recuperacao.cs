﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Odonto_AJRT
{
    public partial class Odonto_recuperacao : Form
    {
        public Odonto_recuperacao()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        MySqlConnection con = new MySqlConnection(@"server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True");
        int i;

        private void Button_vuser_Click(object sender, EventArgs e)
        {
            if (txt_usu.Text != "")
            {
                con.Open();
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from tb_conta where Conta_usu = '" + txt_usu.Text.Trim() + "'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(dt);
                i = Convert.ToInt32(dt.Rows.Count.ToString());

                if (i == 0)
                {
                    MessageBox.Show("Usuário não encontrado");
                    con.Close();
                }
                else
                {

                    Odonto_recuperacao_2 objFrmMain = new Odonto_recuperacao_2(txt_usu.Text);
                    this.Hide();
                    objFrmMain.Show();
                }
            }
            else {
                MessageBox.Show("Digite o nome do usuario");//TO ATUALIZADO
                    }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            form_1 objFrmMain = new form_1();
            this.Hide();
            objFrmMain.Show();
        }

        private void Fechar_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}
