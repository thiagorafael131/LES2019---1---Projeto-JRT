﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft;
using Newtonsoft.Json;
using MySql.Data.MySqlClient;

namespace Odonto_AJRT
{
    public partial class Odonto_cliente : Form
    {
        String rdado;
        public Odonto_cliente(String Dado)
        {
            InitializeComponent();
            rdado = Dado;
            preencher();
            WindowState = FormWindowState.Maximized;

            dataGridView.BorderStyle = BorderStyle.None;
            dataGridView.BackgroundColor = Color.White;

            dataGridView.EnableHeadersVisualStyles = false;
            dataGridView.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 108, 146);
            dataGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        }

        void preencher()
        {
            string MyConnection = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True; convert zero datetime=true";
            MySqlConnection MyConn = new MySqlConnection(MyConnection);
            MyConn.Open();
            MySqlDataAdapter sqlda = new MySqlDataAdapter("select * from odonto_ajrt.tb_cliente where Cliente_ativo = 0 ORDER BY Cliente_nome ASC;", MyConnection);
            DataTable dtbl = new DataTable();
            sqlda.Fill(dtbl);
            dataGridView.AutoGenerateColumns = false;
            dataGridView.DataSource = dtbl;

            MyConn.Close();
        }

        private void ClearData()
        {
            txt_nome.Text = "";
            txt_sobrenome.Text = "";
            txt_email.Text = "";
            txt_rg.Text = "";
            txt_cpf.Text = "";
            dateTimePicker1.Text = DateTime.Now.ToString();
            txt_tel.Text = "";
            txt_cel.Text = "";
            txtCep.Text = "";
            txtEstado.Text = "";
            txtCidade.Text = "";
            txtBairro.Text = "";
            txtRua.Text = "";
            txtNum.Text = "";
        }

        //Função para preencher o GridView

        private void Pesquisa_TextChanged(object sender, EventArgs e)
        {
            if (Pesquisa.Text != "")
            {
                string MyConnection = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True; convert zero datetime=true";
                MySqlConnection MyConn = new MySqlConnection(MyConnection);
                MyConn.Open();
                MySqlDataAdapter sqlda = new MySqlDataAdapter("select * from odonto_ajrt.tb_cliente where Cliente_ativo = 0 and Concat(Cliente_nome,' ',Cliente_sobrenome) like '" + Pesquisa.Text + "%' ORDER BY Cliente_nome ASC;", MyConnection);
                DataTable dtbl = new DataTable();
                sqlda.Fill(dtbl);
                dataGridView.AutoGenerateColumns = false;
                dataGridView.DataSource = dtbl;

                MyConn.Close();
            }
            else { preencher(); }
        }

        private void Voltar_Click(object sender, EventArgs e)
        {
            main_sec_odonto objFrmMain = new main_sec_odonto(rdado);
            this.Hide();
            objFrmMain.Show();
        }

        //Funções e Regras do CEP
        public string BuscaCep(string dados, string cep)
        {
            if (string.IsNullOrEmpty(cep) || cep.Length < 8)
                return string.Empty;
            /*possiveis dados
             * cep logradouro complemento bairro localidade uf unidade ibge gia
             */
            //VAI BUSCAR O TEXTO DO SITE/DOCUMENTO NO ENDERECO ABAIXO
            string ENDERECO = "https://viacep.com.br/ws/" + cep + "/json/";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(ENDERECO);
            request.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36";
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            if (response.StatusCode == HttpStatusCode.OK)
            {
                Stream receiveStream = response.GetResponseStream();
                StreamReader readStream = null;
                readStream = new StreamReader(receiveStream, Encoding.GetEncoding(response.CharacterSet));
                string data = readStream.ReadToEnd();
                dynamic data2 = JsonConvert.DeserializeObject(data);
                return data2[dados];
            }
            else { return "ERRO"; }
        }

        private void txtCep_Leave(object sender, EventArgs e)
        {
            string CEP = txtCep.Text;
            txtEstado.Text = BuscaCep("uf", CEP);
            txtCidade.Text = BuscaCep("localidade", CEP);
            txtBairro.Text = BuscaCep("bairro", CEP);
            txtRua.Text = BuscaCep("logradouro", CEP);
        }

        private void txtCep_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string CEP = txtCep.Text;
                txtEstado.Text = BuscaCep("uf", CEP);
                txtCidade.Text = BuscaCep("localidade", CEP);
                txtBairro.Text = BuscaCep("bairro", CEP);
                txtRua.Text = BuscaCep("logradouro", CEP);
            }
        }

        private void txtCep_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsNumber(e.KeyChar)) && !(e.KeyChar == (char)Keys.Enter) && !(e.KeyChar == (char)Keys.Back))

            {
                txtCep.MaxLength = 8;//aaaa
                e.Handled = true;

            }
        }

        //Regras do texto CPF
        private void txt_cpf_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsNumber(e.KeyChar)) && !(e.KeyChar == (char)Keys.Enter) && !(e.KeyChar == (char)Keys.Back))

            {
                txtCep.MaxLength = 11;//aaaa
                e.Handled = true;

            }
        }

        //Regras do texto RG
        private void txt_rg_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsNumber(e.KeyChar)) && !(e.KeyChar == (char)Keys.Enter) && !(e.KeyChar == (char)Keys.Back))

            {
                txtCep.MaxLength = 9;//aaaa
                e.Handled = true;

            }
        }
        
        //Funções do Botão Registrar
        private void Registrar_Click(object sender, EventArgs e)
        {
            if (txt_nome.Text != "")
            {
                if (txt_sobrenome.Text != "")
                {
                    if (txt_rg.Text != "")
                    {
                        if (txt_cpf.Text != "")
                        {
                            if (txtCep.Text != "")
                            {
                                if (txtBairro.Text != "")
                                {
                                    if (txtRua.Text != "")
                                    {
                                        if (txtNum.Text != "")
                                        {
                                            try
                                            {
                                                //This is my connection string i have assigned the database file address path  
                                                string MyConnection1 = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
                                                //This is my insert query in which i am taking input from the user through windows forms  
                                                string Query1 = "insert into tb_cliente(Cliente_nome,Cliente_sobrenome,Cliente_cpf,Cliente_rg,Cliente_nasc,Cliente_email,Cliente_tel,Cliente_cel,Cliente_cep,Cliente_estado,Cliente_cidade,Cliente_bairro,Cliente_rua,Cliente_num) values('" + this.txt_nome.Text + "','" + this.txt_sobrenome.Text + "','" + this.txt_cpf.Text + "','" + this.txt_rg.Text + "','" + this.dateTimePicker1.Text + "','" + this.txt_email.Text + "','" + this.txt_tel.Text + "','" + this.txt_cel.Text + "','" + this.txtCep.Text + "','" + this.txtEstado.Text + "','" + this.txtCidade.Text + "','" + this.txtBairro.Text + "','" + this.txtRua.Text + "','" + this.txtNum.Text + "');";
                                                //This is  MySqlConnection here i have created the object and pass my connection string.  
                                                MySqlConnection MyConn1 = new MySqlConnection(MyConnection1);
                                                //This is command class which will handle the query and connection object.  
                                                MySqlCommand MyCommand1 = new MySqlCommand(Query1, MyConn1);
                                                MySqlDataReader MyReader1;
                                                MyConn1.Open();
                                                MyReader1 = MyCommand1.ExecuteReader();     // Here our query will be executed and data saved into the database.  

                                                MessageBox.Show("Save Data");
                                                while (MyReader1.Read())
                                                {
                                                }
                                                MyConn1.Close();
                                                
                                            }
                                            catch (Exception ex)
                                            {
                                                MessageBox.Show(ex.Message);
                                            }

                                            preencher();
                                            ClearData();
                                        }
                                        else
                                        {
                                            MessageBox.Show("Informe o Número da residência do Cliente!!");
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Informe a Rua/Avenida do Cliente!!");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Informe o Bairro do Cliente!!");
                                }

                            }
                            else
                            {
                                MessageBox.Show("Informe o CEP do Cliente");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Informe o CPF do Cliente!!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Informe o RG do Cliente!!");
                    }
                }
                else
                {
                    MessageBox.Show("Informe o Sobrenome!!");
                }
            }
            else
            {
                MessageBox.Show("Informe o nome do Funcionario!!");
            }
        }

        private void dataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_nome.Text = dataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
            txt_sobrenome.Text = dataGridView.Rows[e.RowIndex].Cells[1].Value.ToString();
            txt_email.Text = dataGridView.Rows[e.RowIndex].Cells[2].Value.ToString();
            txt_rg.Text = dataGridView.Rows[e.RowIndex].Cells[3].Value.ToString();
            txt_cpf.Text = dataGridView.Rows[e.RowIndex].Cells[4].Value.ToString();
            dateTimePicker1.Text = dataGridView.Rows[e.RowIndex].Cells[5].Value.ToString();
            txt_tel.Text = dataGridView.Rows[e.RowIndex].Cells[6].Value.ToString();
            txt_cel.Text = dataGridView.Rows[e.RowIndex].Cells[7].Value.ToString();
            txtCep.Text = dataGridView.Rows[e.RowIndex].Cells[8].Value.ToString();
            txtEstado.Text = dataGridView.Rows[e.RowIndex].Cells[9].Value.ToString();
            txtCidade.Text = dataGridView.Rows[e.RowIndex].Cells[10].Value.ToString();
            txtBairro.Text = dataGridView.Rows[e.RowIndex].Cells[11].Value.ToString();
            txtRua.Text = dataGridView.Rows[e.RowIndex].Cells[12].Value.ToString();
            txtNum.Text = dataGridView.Rows[e.RowIndex].Cells[13].Value.ToString();

            Registrar.Visible = false;
            txt_cpf.Enabled = false;
        }

        private void Alterar_Click(object sender, EventArgs e)
        {
            if (txt_nome.Text != "")
            {
                if (txt_sobrenome.Text != "")
                {
                    if (txt_rg.Text != "")
                    {
                        if (txt_cpf.Text != "")
                        {
                            if (txtCep.Text != "")
                            {
                                if (txtBairro.Text != "")
                                {
                                    if (txtRua.Text != "")
                                    {
                                        if (txtNum.Text != "")
                                        {
                                            try
                                            {
                                                //This is my connection string i have assigned the database file address path  
                                                string MyConnection1 = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
                                                //This is my insert query in which i am taking input from the user through windows forms  
                                                string Query1 = "update tb_cliente set Cliente_nome = '" + this.txt_nome.Text + "', Cliente_sobrenome = '" + this.txt_sobrenome.Text + "', Cliente_email = '" + this.txt_email.Text + "', Cliente_rg = '" + this.txt_rg.Text + "', Cliente_cpf = '" + this.txt_cpf.Text + "', Cliente_nasc = '" + this.dateTimePicker1.Text + "', Cliente_tel = '" + this.txt_tel.Text + "', Cliente_cel = '" + this.txt_cel.Text + "', Cliente_Cep = '" + this.txtCep.Text + "', Cliente_estado = '" + this.txtEstado.Text + "', Cliente_cidade = '" + this.txtCidade.Text + "', Cliente_bairro = '" + this.txtBairro.Text + "', Cliente_rua = '" + this.txtRua.Text + "', Cliente_num = '" + this.txtNum.Text + "' where Cliente_cpf ='" + this.txt_cpf.Text + "'";
                                                //This is  MySqlConnection here i have created the object and pass my connection string.  
                                                MySqlConnection MyConn1 = new MySqlConnection(MyConnection1);
                                                //This is command class which will handle the query and connection object.  
                                                MySqlCommand MyCommand1 = new MySqlCommand(Query1, MyConn1);
                                                MySqlDataReader MyReader1;
                                                MyConn1.Open();
                                                MyReader1 = MyCommand1.ExecuteReader();     // Here our query will be executed and data saved into the database.  

                                                MessageBox.Show("Informações do Cliente alteradas !!");
                                                while (MyReader1.Read())
                                                {
                                                }
                                                MyConn1.Close();

                                            }
                                            catch (Exception ex)
                                            {
                                                MessageBox.Show(ex.Message);
                                            }

                                            preencher();
                                            ClearData();
                                            Registrar.Visible = true;
                                        }
                                        else
                                        {
                                            MessageBox.Show("Informe o Número da residência do Cliente!!");
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Informe a Rua/Avenida do Cliente!!");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Informe o Bairro do Cliente!!");
                                }

                            }
                            else
                            {
                                MessageBox.Show("Informe o CEP do Cliente");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Informe o CPF do Cliente!!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Informe o RG do Cliente!!");
                    }
                }
                else
                {
                    MessageBox.Show("Informe o Sobrenome!!");
                }
            }
            else
            {
                MessageBox.Show("Informe o nome do Funcionario!!");
            }
        }

        private void Excluir_Click(object sender, EventArgs e)
        {
            if (txt_cpf.Text != "")
            {
                string MyConnection1 = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
                string Query1 = "update tb_cliente set Cliente_ativo = 1 where Cliente_cpf = " + txt_cpf.Text + "";
                MySqlConnection MyConn1 = new MySqlConnection(MyConnection1);
                MySqlCommand MyCommand1 = new MySqlCommand(Query1, MyConn1);
                MySqlDataReader MyReader1;
                MyConn1.Open();
                MyReader1 = MyCommand1.ExecuteReader(); 

                MessageBox.Show("Dados do cliente excluidos");
                while (MyReader1.Read())
                {
                }
                MyConn1.Close();

            }
            else
            {
                MessageBox.Show("Please Select Record to Delete");
            }
            preencher();
            ClearData();
            Registrar.Visible = true;
        }

        private void Fechar_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void Maximizar_Click(object sender, EventArgs e)
        {
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
            this.Maximizar.Visible = false;
            this.Menorizar.Visible = true;
        }

        private void Menorizar_Click(object sender, EventArgs e)
        {
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Normal;
            this.Maximizar.Visible = true;
            this.Menorizar.Visible = false;
        }

        private void Minimizar_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

    }
}
