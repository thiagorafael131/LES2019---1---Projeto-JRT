﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Odonto_AJRT
{
    public partial class Odonto_consultas : Form
    {
        String rdado;
        String temp;
        public Odonto_consultas(String Dado)
        {
            InitializeComponent();
            Fillcombo1();
            rdado = Dado;
            Fillcombo2();
            preencher();
            WindowState = FormWindowState.Maximized;

            dataGridView.BorderStyle = BorderStyle.None;
            dataGridView.BackgroundColor = Color.White;

            dataGridView.EnableHeadersVisualStyles = false;
            dataGridView.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 108, 146);
            dataGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        }

        void Fillcombo1()
        {
            string MyConnection = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
            string Query = "select * from odonto_ajrt.tb_funcionario inner join tb_conta on tb_funcionario.Fun_id=tb_conta.FK_Fun_id INNER JOIN tb_cargo ON tb_conta.FK_Cargo_id=tb_cargo.Cargo_id WHERE Cargo_id = 2;";
            MySqlConnection MyConn = new MySqlConnection(MyConnection);
            MySqlCommand MyCommand = new MySqlCommand(Query, MyConn);
            MySqlDataReader MyReader;
            MyConn.Open();
            MyReader = MyCommand.ExecuteReader();

            while (MyReader.Read())
            {
                string sName = MyReader.GetString("Fun_nome")+" "+ MyReader.GetString("Fun_sobrenome");
                comboBox_nome.Items.Add(sName);
            }
            MyConn.Close();

        }

        void Cleardata() {
            comboBox_cliente.Text = "";
            comboBox_nome.Text = "";
            cbTipo.Text = "";
            dateTimePicker1.Text = "20/04/2019";
            maskedTextBox1.Text = "";
        }

        void Fillcombo2()
        {
            string MyConnection = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
            string Query = "select * from odonto_ajrt.tb_cliente;";
            MySqlConnection MyConn = new MySqlConnection(MyConnection);
            MySqlCommand MyCommand = new MySqlCommand(Query, MyConn);
            MySqlDataReader MyReader;
            MyConn.Open();
            MyReader = MyCommand.ExecuteReader();

            while (MyReader.Read())
            {
                string sName = MyReader.GetString("Cliente_nome")+" "+ MyReader.GetString("Cliente_sobrenome");
                comboBox_cliente.Items.Add(sName);
            }
            MyConn.Close();
        }

        private void Registrar_Click(object sender, EventArgs e)
        {
            string MyConnection = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True; convert zero datetime=true";
            string Query0 = "SELECT Con_data, Con_hora_inicio FROM tb_consulta WHERE con_data = '"+dateTimePicker1.Text+"' AND Con_hora_inicio = '"+maskedTextBox1.Text+"00' and fk_fun_id = '"+IDFunc.Text+"';";
            MySqlConnection MyConn0 = new MySqlConnection(MyConnection);
            MySqlCommand MyCommand0 = new MySqlCommand(Query0, MyConn0);
            MySqlDataReader MyReader0;
            MyConn0.Open();
            MyReader0 = MyCommand0.ExecuteReader();
            if (comboBox_cliente.Text != "")
            {
                if (comboBox_nome.Text != "")
                {
                    if (cbTipo.Text != "")
                    {
                        if (dateTimePicker1.Value.Date >= DateTime.Now)
                        {
                            if (maskedTextBox1.Text != "")
                            {
                                if (MyReader0.Read() != true)
                                {
                                    try
                                    {
                                        string MyConnection3 = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
                                        string sql = "SELECT Hor_id from tb_horario WHERE Hor_hora = '"+maskedTextBox1.Text+"00' LIMIT 1";
                                        MySqlConnection MyConn3 = new MySqlConnection(MyConnection3);
                                        MyConn3.Open();
                                        MySqlCommand MyCommand3 = new MySqlCommand(sql, MyConn3);
                                        MySqlDataReader MyReader3 = MyCommand3.ExecuteReader();

                                        while (MyReader3.Read())
                                        {
                                            temp = MyReader3["Hor_id"].ToString();
                                            
                                        }
                                        MessageBox.Show(temp);
                                        MyConn3.Close();

                                        //This is my connection string i have assigned the database file address path  
                                        string MyConnection1 = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
                                        //This is my insert query in which i am taking input from the user through windows forms  
                                        string Query1 = "insert into tb_consulta(FK_Fun_id,FK_Cliente_id,FK_Hor_id,Con_data,Con_hora_inicio,Con_tipo,Con_obs) values('" + this.IDFunc.Text + "','" + this.IDCliente.Text + "','" + this.temp + "','" + this.dateTimePicker1.Text + "','" + this.maskedTextBox1.Text + "00','" + this.cbTipo.Text + "','" + txtObs.Text + "');";
                                        //This is  MySqlConnection here i have created the object and pass my connection string.  
                                        MySqlConnection MyConn1 = new MySqlConnection(MyConnection1);
                                        //This is command class which will handle the query and connection object.  
                                        MySqlCommand MyCommand1 = new MySqlCommand(Query1, MyConn1);
                                        MySqlDataReader MyReader1;
                                        MyConn1.Open();
                                        MyReader1 = MyCommand1.ExecuteReader();     // Here our query will be executed and data saved into the database.  

                                        MessageBox.Show("Consulta agendada!!");//EU TO FUNCIONANDO
                                        while (MyReader1.Read())
                                        {
                                        }
                                        Cleardata();
                                        MyConn1.Close();
                                    }
                                    catch (Exception ex)
                                    {
                                        MessageBox.Show(ex.Message);
                                    }
                                    MyConn0.Close();
                                }
                                else
                                {
                                    MessageBox.Show("Ja existe uma consulta agendada com este médico neste Horário");
                                    MyConn0.Close();//ESTOU ATUALIZADO
                                }
                            }
                            else
                            {
                                MessageBox.Show("Insira o horário de atendimento!!");
                                MyConn0.Close();
                            }
                        }else{
                            MessageBox.Show("Não inserir data antiga!!");
                            MessageBox.Show(maskedTextBox1.Text);
                            MyConn0.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Preencha o tipo de consulta!!");
                        MyConn0.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Preencha o nome do médico!!");
                    MyConn0.Close();
                }
            }
            else
            {
                MessageBox.Show("Preencha o nome do cliente!!");
                MyConn0.Close();
            }
        }

        private void comboBox_nome_SelectedIndexChanged(object sender, EventArgs e)
        {
            string MyConnection = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
            string Query0 = "select Fun_id from odonto_ajrt.tb_funcionario where Concat(Fun_nome,' ',Fun_sobrenome)= '" + comboBox_nome.Text + "';";
            MySqlConnection MyConn = new MySqlConnection(MyConnection);
            MySqlCommand MyCommand = new MySqlCommand(Query0, MyConn);
            MySqlDataReader MyReader;

            MyConn.Open();
            MyReader = MyCommand.ExecuteReader();
            while (MyReader.Read()) //Coloca o ID do Funcionario no Label_id
            {
                string Idfuncionario = MyReader.GetString("Fun_id");
                IDFunc.Text = Idfuncionario;
            }
            MyConn.Close();
        }

        private void comboBox_cliente_SelectedIndexChanged(object sender, EventArgs e)
        {
            string MyConnection = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
            string Query0 = "select Cliente_id from odonto_ajrt.tb_cliente where Concat(Cliente_nome,' ',Cliente_sobrenome)= '" + comboBox_cliente.Text + "';";
            MySqlConnection MyConn = new MySqlConnection(MyConnection);
            MySqlCommand MyCommand = new MySqlCommand(Query0, MyConn);
            MySqlDataReader MyReader;

            MyConn.Open();
            MyReader = MyCommand.ExecuteReader();
            while (MyReader.Read()) //Coloca o ID do Funcionario no Label_id
            {
                string Idcliente = MyReader.GetString("Cliente_id");
                IDCliente.Text = Idcliente;
            }
            MyConn.Close();
        }

        private void BVoltar_Click(object sender, EventArgs e)
        {
            main_sec_odonto objFrmMain = new main_sec_odonto(rdado);
            this.Hide();
            objFrmMain.Show();
        }

        void preencher()
        {
            string MyConnection = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True; convert zero datetime=true";
            MySqlConnection MyConn = new MySqlConnection(MyConnection);
            MyConn.Open();
            MySqlDataAdapter sqlda = new MySqlDataAdapter("SELECT CONCAT(Fun_nome,' ',Fun_sobrenome) Medico,Fun_cpf,CONCAT(Cliente_nome,' ',Cliente_sobrenome) Cliente,Cliente_cpf,Con_data, Con_hora_inicio FROM odonto_ajrt.tb_cliente tbc inner join tb_consulta tbcon on tbc.Cliente_id=tbcon.FK_Cliente_id INNER JOIN tb_funcionario tbf ON tbcon.FK_Fun_id=tbf.Fun_id inner join tb_conta on tb_conta.FK_Fun_id=tbf.Fun_id where FK_Cargo_id=2 ORDER BY Fun_nome ASC;", MyConnection);
            DataTable dtbl = new DataTable();
            sqlda.Fill(dtbl);
            dataGridView.AutoGenerateColumns = false;
            dataGridView.DataSource = dtbl;

            MyConn.Close();
        }

        private void Pesquisa_TextChanged(object sender, EventArgs e)
        {
            if (Pesquisa.Text != "")
            {
                string MyConnection = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True; convert zero datetime=true";
                MySqlConnection MyConn = new MySqlConnection(MyConnection);
                MyConn.Open();
                MySqlDataAdapter sqlda = new MySqlDataAdapter("SELECT CONCAT(Fun_nome,' ',Fun_sobrenome) Medico,Fun_cpf,CONCAT(Cliente_nome,' ',Cliente_sobrenome) Cliente,Cliente_cpf,Con_data, Con_hora_inicio FROM odonto_ajrt.tb_cliente tbc inner join tb_consulta tbcon on tbc.Cliente_id=tbcon.FK_Cliente_id INNER JOIN tb_funcionario tbf ON tbcon.FK_Fun_id=tbf.Fun_id inner join tb_conta on tb_conta.FK_Fun_id=tbf.Fun_id where FK_Cargo_id=2 and Concat(Fun_nome,' ',Fun_sobrenome) like '" + Pesquisa.Text + "%' ORDER BY Fun_nome ASC;", MyConnection);
                DataTable dtbl = new DataTable();
                sqlda.Fill(dtbl);
                dataGridView.AutoGenerateColumns = false;
                dataGridView.DataSource = dtbl;

                MyConn.Close();
            }
            else { preencher(); }
        }

        private void dataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            comboBox_cliente.Text = dataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
            comboBox_nome.Text = dataGridView.Rows[e.RowIndex].Cells[2].Value.ToString();
            dateTimePicker1.Text = dataGridView.Rows[e.RowIndex].Cells[4].Value.ToString();
            maskedTextBox1.Text = dataGridView.Rows[e.RowIndex].Cells[5].Value.ToString();

            Registrar.Visible = false;
        }

        private void Fechar_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void Maximizar_Click(object sender, EventArgs e)
        {
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
            this.Maximizar.Visible = false;
            this.Menorizar.Visible = true;
        }

        private void Menorizar_Click(object sender, EventArgs e)
        {
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Normal;
            this.Maximizar.Visible = true;
            this.Menorizar.Visible = false;
        }

        private void Minimizar_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }
    }
}
