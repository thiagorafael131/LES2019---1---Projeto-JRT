﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft;
using Newtonsoft.Json;
using MySql.Data.MySqlClient;

namespace Odonto_AJRT
{
    public partial class Odonto_funcionario : Form
    {
        String rdado;
        public Odonto_funcionario(String Dado)
        {
            
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            preencher();
            rdado = Dado;

            dataGridView.BorderStyle = BorderStyle.None;
            dataGridView.BackgroundColor = Color.White;

            dataGridView.EnableHeadersVisualStyles = false;
            dataGridView.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 108, 146);
            dataGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

        }

        void preencher()
        {
            string MyConnection = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True; convert zero datetime=true";
            MySqlConnection MyConn = new MySqlConnection(MyConnection);
            MyConn.Open(); //EU SOU A ULTIMA VERSÃO
            MySqlDataAdapter sqlda = new MySqlDataAdapter("select * from odonto_ajrt.tb_funcionario inner join tb_conta on tb_funcionario.Fun_id=tb_conta.FK_Fun_id where FK_Cargo_id=2 or FK_Cargo_id=3;", MyConnection);
            DataTable dtbl = new DataTable();
            sqlda.Fill(dtbl);
            dataGridView.AutoGenerateColumns = false;
            dataGridView.DataSource = dtbl;

            MyConn.Close();
        }

        public string BuscaCep(string dados, string cep)
        {
            if (string.IsNullOrEmpty(cep) || cep.Length < 8)
                return string.Empty;
            /*possiveis dados
             * cep logradouro complemento bairro localidade uf unidade ibge gia
             */
            //VAI BUSCAR O TEXTO DO SITE/DOCUMENTO NO ENDERECO ABAIXO
            string ENDERECO = "https://viacep.com.br/ws/" + cep + "/json/";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(ENDERECO);
            request.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36";
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            if (response.StatusCode == HttpStatusCode.OK)
            {
                Stream receiveStream = response.GetResponseStream();
                StreamReader readStream = null;
                readStream = new StreamReader(receiveStream, Encoding.GetEncoding(response.CharacterSet));
                string data = readStream.ReadToEnd();
                dynamic data2 = JsonConvert.DeserializeObject(data);
                return data2[dados];
            }
            else { return "ERRO"; }
        }

        private void txtCep_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string CEP = txtCep.Text;
                txtEstado.Text = BuscaCep("uf", CEP);
                txtCidade.Text = BuscaCep("localidade", CEP);
                txtBairro.Text = BuscaCep("bairro", CEP);
                txtRua.Text = BuscaCep("logradouro", CEP);
            }
        }

        private void textCep_Leave(object sender, EventArgs e)
        {
                string CEP = txtCep.Text;
                txtEstado.Text = BuscaCep("uf", CEP);
                txtCidade.Text = BuscaCep("localidade", CEP);
                txtBairro.Text = BuscaCep("bairro", CEP);
                txtRua.Text = BuscaCep("logradouro", CEP);
        }

        private void Registrar_Click(object sender, EventArgs e)
        {

            if (CB_cargo.Text == "Administrador")//a
            {
                CB_cargo.Text = "1";
            }
            else if (CB_cargo.Text == "Dentista")
            {
                CB_cargo.Text = "2";
            }
            else if (CB_cargo.Text == "Secretario")
            {
                CB_cargo.Text = "3";
            }
            else { MessageBox.Show("Selecione uma categoria"); }
            if (txt_nome.Text != "")
            {
                if (txt_usu.Text != "")
                {
                    if (txt_sobrenome.Text != "")
                    {
                        if (txtCep.Text != "")
                        {
                            if (txtNum.Text != "")
                            {
                                if (txt_senha.Text != "")
                                {
                                    if (txt_senha.Text == txt_csenha.Text)
                                    {
                                        try
                                        {
                                            //This is my connection string i have assigned the database file address path  
                                            string MyConnection1 = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
                                            //This is my insert query in which i am taking input from the user through windows forms  
                                            string Query1 = "insert into tb_funcionario(Fun_nome,Fun_sobrenome,Fun_email,Fun_cpf,Fun_rg,Fun_nasc,Fun_tel,Fun_cel,Fun_cep,Fun_estado,Fun_cidade,Fun_bairro,Fun_rua,Fun_num) values('" + this.txt_nome.Text + "','" + this.txt_sobrenome.Text + "','" + this.txt_email.Text + "','" + this.txt_cpf.Text + "','" + this.txt_rg.Text + "','" + this.dateTimePicker1.Text + "','" + this.txt_tel.Text + "','" + this.txt_cel.Text + "','" + this.txtCep.Text + "','" + this.txtEstado.Text + "','" + this.txtCidade.Text + "','" + this.txtBairro.Text + "','" + this.txtRua.Text + "','" + this.txtNum.Text + "');";
                                            //This is  MySqlConnection here i have created the object and pass my connection string.  
                                            MySqlConnection MyConn1 = new MySqlConnection(MyConnection1);
                                            //This is command class which will handle the query and connection object.  
                                            MySqlCommand MyCommand1 = new MySqlCommand(Query1, MyConn1);
                                            MySqlDataReader MyReader1;
                                            MyConn1.Open();
                                            MyReader1 = MyCommand1.ExecuteReader();     // Here our query will be executed and data saved into the database.  

                                            MessageBox.Show("Save Data");
                                            while (MyReader1.Read())
                                            {
                                            }
                                            MyConn1.Close();

                                            //MyConn1.Open();
                                            string Query2 = "insert into tb_conta(Conta_usu,Conta_senha,FK_Fun_id,FK_Cargo_id) values('" + this.txt_usu.Text + "','" + this.txt_senha.Text + "',(select Fun_id from tb_funcionario ORDER BY Fun_id DESC LIMIT 1),'" + CB_cargo.Text + "');";
                                            MySqlCommand MyCommand2 = new MySqlCommand(Query2, MyConn1);
                                            MySqlDataReader MyReader2;
                                            MyConn1.Open();
                                            MyReader2 = MyCommand2.ExecuteReader();     // Here our query will be executed and data saved into the database.  

                                            MessageBox.Show("Save Data");
                                            while (MyReader2.Read())
                                            {
                                            }
                                            MyConn1.Close();

                                        }
                                        catch (Exception ex)
                                        {
                                            MessageBox.Show(ex.Message);
                                        }

                                        preencher();
                                    }
                                    else
                                    {
                                        MessageBox.Show("Senhas não coincidem!!");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Informe uma senha!!");
                                }

                            }
                            else
                            {
                                MessageBox.Show("Informe o Número da residencia!!");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Informe o CEP!!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Informe o sobrenome do funcionario!!");
                    }
                }
                else
                {
                    MessageBox.Show("Informe o Usuario!!");
                }
            }
            else
            {
                MessageBox.Show("Informe o nome do Funcionario!!");
            }

        }

        private void txtCep_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsNumber(e.KeyChar)) && !(e.KeyChar == (char)Keys.Enter) && !(e.KeyChar == (char)Keys.Back))

            {
                txtCep.MaxLength = 8;//aaaa
                e.Handled = true;

            }
        }

        private void Pesquisa_TextChanged(object sender, EventArgs e)
        {
            if (Pesquisa.Text != "")
            {
                string MyConnection = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True; convert zero datetime=true";
                MySqlConnection MyConn = new MySqlConnection(MyConnection);
                MyConn.Open();
                MySqlDataAdapter sqlda = new MySqlDataAdapter("select * from odonto_ajrt.tb_funcionario inner join tb_conta on tb_funcionario.Fun_id=tb_conta.FK_Fun_id WHERE FK_Cargo_id NOT IN (1) and Fun_nome like '" + Pesquisa.Text + "%' ORDER BY Fun_nome ASC;", MyConnection);
                DataTable dtbl = new DataTable();
                sqlda.Fill(dtbl);
                dataGridView.AutoGenerateColumns = false;
                dataGridView.DataSource = dtbl;

                MyConn.Close();
            }
            else { preencher(); }
        }

        private void BEsquerda_Click(object sender, EventArgs e)
        {
            main_odonto objFrmMain = new main_odonto(rdado);
            this.Hide();
            objFrmMain.Show();
        }

        private void Minimizar_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void Menorizar_Click(object sender, EventArgs e)
        {
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Normal;
            this.Maximizar.Visible = true;
            this.Menorizar.Visible = false;
        }

        private void Maximizar_Click(object sender, EventArgs e)
        {
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
            this.Maximizar.Visible = false;
            this.Menorizar.Visible = true;
        }

        private void Fechar_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}
