﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
//TO ATUALIZADO

namespace Odonto_AJRT
{
    public partial class main_odonto : Form
    {
        String rdado;

        public main_odonto(String Dado)
        {
            InitializeComponent();
            rdado = Dado;
            WindowState = FormWindowState.Maximized;
            string MyConnection1 = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
            
            string sql = "SELECT * from tb_funcionario inner join tb_conta on tb_funcionario.Fun_id=tb_conta.FK_Fun_id where Conta_usu = '"+rdado+"'";
            MySqlConnection MyConn1 = new MySqlConnection(MyConnection1);
            MyConn1.Open();
            MySqlCommand MyCommand1 = new MySqlCommand(sql, MyConn1);
            MySqlDataReader MyReader1 = MyCommand1.ExecuteReader();//;
            
            if (MyReader1.Read()) {
                txt_nome.Text = MyReader1["Fun_nome"].ToString() + " " + MyReader1["Fun_sobrenome"].ToString();
            }
            MyConn1.Close();

            string MyConnection2 = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
            string sql2 = "SELECT * from tb_cargo inner join tb_conta on tb_cargo.Cargo_id=tb_conta.FK_Cargo_id where Conta_usu = '" + rdado + "'";
            MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);
            MyConn2.Open();
            MySqlCommand MyCommand2 = new MySqlCommand(sql2, MyConn2);
            MySqlDataReader MyReader2 = MyCommand2.ExecuteReader(); ;

            if (MyReader2.Read())
            {
                txt_cargo.Text = MyReader2["Cargo_nome"].ToString();//ATUALIZADO
            }
            MyConn2.Close();

        }

        public main_odonto()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;

        }

        private void label5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Cliente_Click(object sender, EventArgs e)
        {
            Odonto_funcionario objFrmMain = new Odonto_funcionario(rdado);
            this.Hide();
            objFrmMain.Show();
        }

        private void Minimizar_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void Menorizar_Click(object sender, EventArgs e)
        {
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Normal;
            this.Maximizar.Visible = true;
            this.Menorizar.Visible = false;
        }

        private void Maximizar_Click(object sender, EventArgs e)
        {
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
            this.Maximizar.Visible = false;
            this.Menorizar.Visible = true;
        }

        private void Fechar_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void Financeiro_Click(object sender, EventArgs e)
        {
            Odonto_contas objFrmMain = new Odonto_contas(rdado);
            this.Hide();
            objFrmMain.Show();
        }

        private void Finalizar_Click(object sender, EventArgs e)
        {
            form_1 objFrmMain = new form_1();
            this.Hide();
            objFrmMain.Show();
        }
    }
}
