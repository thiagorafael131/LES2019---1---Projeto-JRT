﻿namespace Odonto_AJRT
{
    partial class main_sec_odonto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(main_sec_odonto));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.jDragControl1 = new JDragControl.JDragControl(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.Fechar = new System.Windows.Forms.PictureBox();
            this.Minimizar = new System.Windows.Forms.PictureBox();
            this.Menorizar = new System.Windows.Forms.PictureBox();
            this.Maximizar = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Estoque = new JThinButton.JThinButton();
            this.Consulta = new JThinButton.JThinButton();
            this.Cliente = new JThinButton.JThinButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.txt_nome = new System.Windows.Forms.Label();
            this.txt_cargo = new System.Windows.Forms.Label();
            this.Finalizar = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Fechar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minimizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Menorizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Maximizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Finalizar)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // jDragControl1
            // 
            this.jDragControl1.GetForm = this;
            this.jDragControl1.TargetControl = this.panel1;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.Fechar);
            this.panel1.Controls.Add(this.Minimizar);
            this.panel1.Controls.Add(this.Menorizar);
            this.panel1.Controls.Add(this.Maximizar);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1360, 23);
            this.panel1.TabIndex = 2;
            // 
            // Fechar
            // 
            this.Fechar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Fechar.Image = ((System.Drawing.Image)(resources.GetObject("Fechar.Image")));
            this.Fechar.Location = new System.Drawing.Point(1347, 6);
            this.Fechar.Name = "Fechar";
            this.Fechar.Size = new System.Drawing.Size(10, 10);
            this.Fechar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Fechar.TabIndex = 32;
            this.Fechar.TabStop = false;
            this.Fechar.Click += new System.EventHandler(this.Fechar_Click);
            // 
            // Minimizar
            // 
            this.Minimizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Minimizar.Image = ((System.Drawing.Image)(resources.GetObject("Minimizar.Image")));
            this.Minimizar.Location = new System.Drawing.Point(1317, 6);
            this.Minimizar.Name = "Minimizar";
            this.Minimizar.Size = new System.Drawing.Size(10, 10);
            this.Minimizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Minimizar.TabIndex = 30;
            this.Minimizar.TabStop = false;
            this.Minimizar.Click += new System.EventHandler(this.Minimizar_Click);
            // 
            // Menorizar
            // 
            this.Menorizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Menorizar.Image = ((System.Drawing.Image)(resources.GetObject("Menorizar.Image")));
            this.Menorizar.Location = new System.Drawing.Point(1333, 6);
            this.Menorizar.Name = "Menorizar";
            this.Menorizar.Size = new System.Drawing.Size(10, 10);
            this.Menorizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Menorizar.TabIndex = 31;
            this.Menorizar.TabStop = false;
            this.Menorizar.Click += new System.EventHandler(this.Menorizar_Click);
            // 
            // Maximizar
            // 
            this.Maximizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Maximizar.Image = ((System.Drawing.Image)(resources.GetObject("Maximizar.Image")));
            this.Maximizar.Location = new System.Drawing.Point(1333, 6);
            this.Maximizar.Name = "Maximizar";
            this.Maximizar.Size = new System.Drawing.Size(10, 10);
            this.Maximizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Maximizar.TabIndex = 30;
            this.Maximizar.TabStop = false;
            this.Maximizar.Visible = false;
            this.Maximizar.Click += new System.EventHandler(this.Maximizar_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(58, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(250, 110);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // Estoque
            // 
            this.Estoque.BackColor = System.Drawing.Color.Transparent;
            this.Estoque.BackgroundColor = System.Drawing.Color.Transparent;
            this.Estoque.BorderColor = System.Drawing.Color.Transparent;
            this.Estoque.BorderRadius = 0;
            this.Estoque.ButtonText = "Estoque";
            this.Estoque.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Estoque.Font_Size = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Estoque.ForeColors = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(163)))), ((int)(((byte)(165)))));
            this.Estoque.HoverBackground = System.Drawing.Color.Transparent;
            this.Estoque.HoverBorder = System.Drawing.Color.Transparent;
            this.Estoque.HoverFontColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Estoque.LineThickness = 2;
            this.Estoque.Location = new System.Drawing.Point(715, 36);
            this.Estoque.Margin = new System.Windows.Forms.Padding(11, 9, 11, 9);
            this.Estoque.Name = "Estoque";
            this.Estoque.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Estoque.Size = new System.Drawing.Size(117, 44);
            this.Estoque.TabIndex = 30;
            this.Estoque.Click += new System.EventHandler(this.Estoque_Click);
            // 
            // Consulta
            // 
            this.Consulta.BackColor = System.Drawing.Color.Transparent;
            this.Consulta.BackgroundColor = System.Drawing.Color.Transparent;
            this.Consulta.BorderColor = System.Drawing.Color.Transparent;
            this.Consulta.BorderRadius = 0;
            this.Consulta.ButtonText = "Consultas";
            this.Consulta.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Consulta.Font_Size = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Consulta.ForeColors = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(163)))), ((int)(((byte)(165)))));
            this.Consulta.HoverBackground = System.Drawing.Color.Transparent;
            this.Consulta.HoverBorder = System.Drawing.Color.Transparent;
            this.Consulta.HoverFontColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Consulta.LineThickness = 2;
            this.Consulta.Location = new System.Drawing.Point(557, 36);
            this.Consulta.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Consulta.Name = "Consulta";
            this.Consulta.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Consulta.Size = new System.Drawing.Size(141, 44);
            this.Consulta.TabIndex = 4;
            this.Consulta.Click += new System.EventHandler(this.Consulta_Click);
            // 
            // Cliente
            // 
            this.Cliente.BackColor = System.Drawing.Color.Transparent;
            this.Cliente.BackgroundColor = System.Drawing.Color.White;
            this.Cliente.BorderColor = System.Drawing.Color.White;
            this.Cliente.BorderRadius = 0;
            this.Cliente.ButtonText = "Área do Cliente";
            this.Cliente.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cliente.Font_Size = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cliente.ForeColors = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(163)))), ((int)(((byte)(165)))));
            this.Cliente.HoverBackground = System.Drawing.Color.White;
            this.Cliente.HoverBorder = System.Drawing.Color.White;
            this.Cliente.HoverFontColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Cliente.LineThickness = 2;
            this.Cliente.Location = new System.Drawing.Point(316, 36);
            this.Cliente.Margin = new System.Windows.Forms.Padding(11, 9, 11, 9);
            this.Cliente.Name = "Cliente";
            this.Cliente.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Cliente.Size = new System.Drawing.Size(224, 44);
            this.Cliente.TabIndex = 5;
            this.Cliente.Click += new System.EventHandler(this.Cliente_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(941, 13);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(90, 90);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 26;
            this.pictureBox2.TabStop = false;
            // 
            // txt_nome
            // 
            this.txt_nome.AutoSize = true;
            this.txt_nome.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(163)))), ((int)(((byte)(165)))));
            this.txt_nome.Location = new System.Drawing.Point(1037, 23);
            this.txt_nome.Name = "txt_nome";
            this.txt_nome.Size = new System.Drawing.Size(140, 33);
            this.txt_nome.TabIndex = 33;
            this.txt_nome.Text = "txt_nome";
            // 
            // txt_cargo
            // 
            this.txt_cargo.AutoSize = true;
            this.txt_cargo.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_cargo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(163)))), ((int)(((byte)(165)))));
            this.txt_cargo.Location = new System.Drawing.Point(1037, 59);
            this.txt_cargo.Name = "txt_cargo";
            this.txt_cargo.Size = new System.Drawing.Size(141, 33);
            this.txt_cargo.TabIndex = 34;
            this.txt_cargo.Text = "txt_cargo";
            // 
            // Finalizar
            // 
            this.Finalizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Finalizar.Image = ((System.Drawing.Image)(resources.GetObject("Finalizar.Image")));
            this.Finalizar.Location = new System.Drawing.Point(1288, 35);
            this.Finalizar.Name = "Finalizar";
            this.Finalizar.Size = new System.Drawing.Size(46, 46);
            this.Finalizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Finalizar.TabIndex = 35;
            this.Finalizar.TabStop = false;
            this.Finalizar.Click += new System.EventHandler(this.Finalizar_Click);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.Controls.Add(this.txt_cargo);
            this.panel2.Controls.Add(this.txt_nome);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.Estoque);
            this.panel2.Controls.Add(this.Consulta);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.Cliente);
            this.panel2.Controls.Add(this.Finalizar);
            this.panel2.Location = new System.Drawing.Point(0, 22);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1360, 153);
            this.panel2.TabIndex = 36;
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Font = new System.Drawing.Font("Century Gothic", 32.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monthCalendar1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.monthCalendar1.Location = new System.Drawing.Point(0, 174);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 38;
            this.monthCalendar1.TitleBackColor = System.Drawing.Color.White;
            this.monthCalendar1.TitleForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.monthCalendar1.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridView1.Location = new System.Drawing.Point(715, 174);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(642, 494);
            this.dataGridView1.TabIndex = 39;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "Hor_hora";
            this.Column1.HeaderText = "Horário da consulta";
            this.Column1.Name = "Column1";
            this.Column1.Width = 297;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "Medico";
            this.Column2.HeaderText = "Coluna1";
            this.Column2.Name = "Column2";
            this.Column2.Width = 300;
            // 
            // main_sec_odonto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1360, 728);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.monthCalendar1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "main_sec_odonto";
            this.Text = "main_sec_odonto";
            this.Load += new System.EventHandler(this.main_sec_odonto_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Fechar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minimizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Menorizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Maximizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Finalizar)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private JDragControl.JDragControl jDragControl1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private JThinButton.JThinButton Consulta;
        private JThinButton.JThinButton Cliente;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox Maximizar;
        private System.Windows.Forms.PictureBox Menorizar;
        private System.Windows.Forms.PictureBox Minimizar;
        private JThinButton.JThinButton Estoque;
        private System.Windows.Forms.Label txt_nome;
        private System.Windows.Forms.Label txt_cargo;
        private System.Windows.Forms.PictureBox Fechar;
        private System.Windows.Forms.PictureBox Finalizar;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
    }
}