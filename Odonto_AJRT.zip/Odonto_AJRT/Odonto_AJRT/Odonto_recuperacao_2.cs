﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Odonto_AJRT
{
    public partial class Odonto_recuperacao_2 : Form
    {
        public Odonto_recuperacao_2()
        {
            InitializeComponent();
            
        }

        String rdado;

        public Odonto_recuperacao_2(String Dado)
        {
            InitializeComponent();
            rdado = Dado;
            this.StartPosition = FormStartPosition.CenterScreen;

        }//aaaaaa

        private void Button_vsenha_Click(object sender, EventArgs e)
        {
            if (txt_senha.Text != "")
            {
                if (txt_senha.Text == txt_senha2.Text)
                {
                    try
                    {
                        //VOCÊ TEM QUE DAR UM JEITO DE JOGAR A VARIAVEL DE ODONTO_RECUPARACAO PARA ODONTO_RECUPERACAO2;
                        //This is my connection string i have assigned the database file address path  
                        string MyConnection2 = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
                        //This is my update query in which i am taking input from the user through windows forms and update the record.  
                        string Query = "update tb_conta set Conta_senha='" + this.txt_senha.Text + "' where Conta_usu ='" + rdado + "';";
                        //This is  MySqlConnection here i have created the object and pass my connection string.  
                        MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);
                        MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                        MySqlDataReader MyReader2;
                        MyConn2.Open();
                        MyReader2 = MyCommand2.ExecuteReader();
                        MessageBox.Show("Data Updated");
                        while (MyReader2.Read())
                        {
                        }
                        MyConn2.Close();//Connection closed here  
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show("As senhas não são idênticas !!");
                }
            }
            else {
                MessageBox.Show("Digite a nova senha !!");
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Odonto_recuperacao objFrmMain = new Odonto_recuperacao();
            this.Hide();
            objFrmMain.Show();
        }

        private void Fechar_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}
