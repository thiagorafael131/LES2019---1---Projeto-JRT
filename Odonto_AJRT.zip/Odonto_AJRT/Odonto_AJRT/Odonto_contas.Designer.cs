﻿namespace Odonto_AJRT
{
    partial class Odonto_contas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Odonto_contas));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Maximizar = new System.Windows.Forms.PictureBox();
            this.Fechar = new System.Windows.Forms.PictureBox();
            this.Menorizar = new System.Windows.Forms.PictureBox();
            this.Minimizar = new System.Windows.Forms.PictureBox();
            this.jDragControl1 = new JDragControl.JDragControl(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.BEsquerda = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.Pesquisa = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Excluir1 = new JThinButton.JThinButton();
            this.Alterar1 = new JThinButton.JThinButton();
            this.Cadastrar1 = new JThinButton.JThinButton();
            this.txt_parc1 = new System.Windows.Forms.TextBox();
            this.txt_quant1 = new System.Windows.Forms.TextBox();
            this.txt_valor1 = new System.Windows.Forms.TextBox();
            this.txt_venc1 = new System.Windows.Forms.DateTimePicker();
            this.label15 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label14 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.txt_desc1 = new System.Windows.Forms.TextBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_fornecedor = new System.Windows.Forms.TextBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.FCaixa = new System.Windows.Forms.Label();
            this.Receber = new System.Windows.Forms.Label();
            this.Pagar = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.Excluir2 = new JThinButton.JThinButton();
            this.Alterar2 = new JThinButton.JThinButton();
            this.Cadastrar2 = new JThinButton.JThinButton();
            this.txt_parc2 = new System.Windows.Forms.TextBox();
            this.txt_quant2 = new System.Windows.Forms.TextBox();
            this.txt_valor2 = new System.Windows.Forms.TextBox();
            this.txt_emi = new System.Windows.Forms.DateTimePicker();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.txt_desc2 = new System.Windows.Forms.TextBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txt_cliente = new System.Windows.Forms.TextBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.txt_venc2 = new System.Windows.Forms.DateTimePicker();
            this.label18 = new System.Windows.Forms.Label();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID = new System.Windows.Forms.Label();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.entradas = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ID1 = new System.Windows.Forms.Label();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.saidas = new System.Windows.Forms.TextBox();
            this.resultado = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Maximizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Fechar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Menorizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minimizar)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BEsquerda)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.Maximizar);
            this.panel1.Controls.Add(this.Fechar);
            this.panel1.Controls.Add(this.Menorizar);
            this.panel1.Controls.Add(this.Minimizar);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1175, 23);
            this.panel1.TabIndex = 4;
            // 
            // Maximizar
            // 
            this.Maximizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Maximizar.Image = ((System.Drawing.Image)(resources.GetObject("Maximizar.Image")));
            this.Maximizar.Location = new System.Drawing.Point(1148, 6);
            this.Maximizar.Name = "Maximizar";
            this.Maximizar.Size = new System.Drawing.Size(10, 10);
            this.Maximizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Maximizar.TabIndex = 146;
            this.Maximizar.TabStop = false;
            this.Maximizar.Visible = false;
            this.Maximizar.Click += new System.EventHandler(this.Maximizar_Click);
            // 
            // Fechar
            // 
            this.Fechar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Fechar.Image = ((System.Drawing.Image)(resources.GetObject("Fechar.Image")));
            this.Fechar.Location = new System.Drawing.Point(1162, 6);
            this.Fechar.Name = "Fechar";
            this.Fechar.Size = new System.Drawing.Size(10, 10);
            this.Fechar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Fechar.TabIndex = 148;
            this.Fechar.TabStop = false;
            this.Fechar.Click += new System.EventHandler(this.Fechar_Click);
            // 
            // Menorizar
            // 
            this.Menorizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Menorizar.Image = ((System.Drawing.Image)(resources.GetObject("Menorizar.Image")));
            this.Menorizar.Location = new System.Drawing.Point(1148, 6);
            this.Menorizar.Name = "Menorizar";
            this.Menorizar.Size = new System.Drawing.Size(10, 10);
            this.Menorizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Menorizar.TabIndex = 147;
            this.Menorizar.TabStop = false;
            this.Menorizar.Click += new System.EventHandler(this.Menorizar_Click);
            // 
            // Minimizar
            // 
            this.Minimizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Minimizar.Image = ((System.Drawing.Image)(resources.GetObject("Minimizar.Image")));
            this.Minimizar.Location = new System.Drawing.Point(1132, 6);
            this.Minimizar.Name = "Minimizar";
            this.Minimizar.Size = new System.Drawing.Size(10, 10);
            this.Minimizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Minimizar.TabIndex = 145;
            this.Minimizar.TabStop = false;
            this.Minimizar.Click += new System.EventHandler(this.Minimizar_Click);
            // 
            // jDragControl1
            // 
            this.jDragControl1.GetForm = this;
            this.jDragControl1.TargetControl = this.panel1;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.BEsquerda);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Location = new System.Drawing.Point(0, 22);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1175, 153);
            this.panel2.TabIndex = 166;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label19.Location = new System.Drawing.Point(314, 74);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(249, 38);
            this.label19.TabIndex = 165;
            this.label19.Text = "Fluxo de Caixa";
            // 
            // BEsquerda
            // 
            this.BEsquerda.BackColor = System.Drawing.Color.Transparent;
            this.BEsquerda.Image = ((System.Drawing.Image)(resources.GetObject("BEsquerda.Image")));
            this.BEsquerda.Location = new System.Drawing.Point(12, 36);
            this.BEsquerda.Name = "BEsquerda";
            this.BEsquerda.Size = new System.Drawing.Size(32, 41);
            this.BEsquerda.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BEsquerda.TabIndex = 3;
            this.BEsquerda.TabStop = false;
            this.BEsquerda.Click += new System.EventHandler(this.BEsquerda_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(58, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(250, 110);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label21.Location = new System.Drawing.Point(527, 6);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(114, 28);
            this.label21.TabIndex = 171;
            this.label21.Text = "Entradas";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label2.Location = new System.Drawing.Point(781, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 28);
            this.label2.TabIndex = 173;
            this.label2.Text = "Saídas";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label4.Location = new System.Drawing.Point(1004, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(130, 28);
            this.label4.TabIndex = 175;
            this.label4.Text = "Resultado";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox17.Image")));
            this.pictureBox17.Location = new System.Drawing.Point(13, 18);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(400, 34);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox17.TabIndex = 178;
            this.pictureBox17.TabStop = false;
            // 
            // Pesquisa
            // 
            this.Pesquisa.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.Pesquisa.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.Pesquisa.BackColor = System.Drawing.Color.White;
            this.Pesquisa.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Pesquisa.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pesquisa.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.Pesquisa.Location = new System.Drawing.Point(29, 25);
            this.Pesquisa.Name = "Pesquisa";
            this.Pesquisa.Size = new System.Drawing.Size(371, 20);
            this.Pesquisa.TabIndex = 179;
            this.Pesquisa.Text = "Pesquisar";
            this.Pesquisa.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Pesquisa.TextChanged += new System.EventHandler(this.Pesquisa_TextChanged);
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.resultado);
            this.panel3.Controls.Add(this.saidas);
            this.panel3.Controls.Add(this.entradas);
            this.panel3.Controls.Add(this.dataGridView);
            this.panel3.Controls.Add(this.Pesquisa);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.pictureBox17);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label21);
            this.panel3.Location = new System.Drawing.Point(12, 253);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1155, 523);
            this.panel3.TabIndex = 180;
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.Controls.Add(this.ID1);
            this.panel4.Controls.Add(this.dataGridView1);
            this.panel4.Controls.Add(this.Excluir1);
            this.panel4.Controls.Add(this.Alterar1);
            this.panel4.Controls.Add(this.Cadastrar1);
            this.panel4.Controls.Add(this.txt_parc1);
            this.panel4.Controls.Add(this.txt_quant1);
            this.panel4.Controls.Add(this.txt_valor1);
            this.panel4.Controls.Add(this.txt_venc1);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Controls.Add(this.pictureBox7);
            this.panel4.Controls.Add(this.label14);
            this.panel4.Controls.Add(this.pictureBox6);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.pictureBox5);
            this.panel4.Controls.Add(this.txt_desc1);
            this.panel4.Controls.Add(this.pictureBox4);
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.pictureBox3);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.txt_fornecedor);
            this.panel4.Controls.Add(this.pictureBox14);
            this.panel4.Location = new System.Drawing.Point(12, 253);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1155, 523);
            this.panel4.TabIndex = 184;
            this.panel4.Visible = false;
            // 
            // Excluir1
            // 
            this.Excluir1.BackColor = System.Drawing.Color.Transparent;
            this.Excluir1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Excluir1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Excluir1.BorderRadius = 12;
            this.Excluir1.ButtonText = "Excluir";
            this.Excluir1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Excluir1.Font_Size = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Excluir1.ForeColors = System.Drawing.Color.White;
            this.Excluir1.HoverBackground = System.Drawing.Color.MediumSeaGreen;
            this.Excluir1.HoverBorder = System.Drawing.Color.MediumSeaGreen;
            this.Excluir1.HoverFontColor = System.Drawing.Color.White;
            this.Excluir1.LineThickness = 2;
            this.Excluir1.Location = new System.Drawing.Point(109, 445);
            this.Excluir1.Margin = new System.Windows.Forms.Padding(4);
            this.Excluir1.Name = "Excluir1";
            this.Excluir1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Excluir1.Size = new System.Drawing.Size(179, 33);
            this.Excluir1.TabIndex = 177;
            this.Excluir1.Click += new System.EventHandler(this.Excluir1_Click);
            // 
            // Alterar1
            // 
            this.Alterar1.BackColor = System.Drawing.Color.Transparent;
            this.Alterar1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Alterar1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Alterar1.BorderRadius = 12;
            this.Alterar1.ButtonText = "Alterar";
            this.Alterar1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alterar1.Font_Size = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alterar1.ForeColors = System.Drawing.Color.White;
            this.Alterar1.HoverBackground = System.Drawing.Color.MediumSeaGreen;
            this.Alterar1.HoverBorder = System.Drawing.Color.MediumSeaGreen;
            this.Alterar1.HoverFontColor = System.Drawing.Color.White;
            this.Alterar1.LineThickness = 2;
            this.Alterar1.Location = new System.Drawing.Point(109, 404);
            this.Alterar1.Margin = new System.Windows.Forms.Padding(4);
            this.Alterar1.Name = "Alterar1";
            this.Alterar1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Alterar1.Size = new System.Drawing.Size(179, 33);
            this.Alterar1.TabIndex = 176;
            this.Alterar1.Click += new System.EventHandler(this.Alterar1_Click);
            // 
            // Cadastrar1
            // 
            this.Cadastrar1.BackColor = System.Drawing.Color.Transparent;
            this.Cadastrar1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Cadastrar1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Cadastrar1.BorderRadius = 12;
            this.Cadastrar1.ButtonText = "Cadastrar";
            this.Cadastrar1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cadastrar1.Font_Size = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cadastrar1.ForeColors = System.Drawing.Color.White;
            this.Cadastrar1.HoverBackground = System.Drawing.Color.MediumSeaGreen;
            this.Cadastrar1.HoverBorder = System.Drawing.Color.MediumSeaGreen;
            this.Cadastrar1.HoverFontColor = System.Drawing.Color.White;
            this.Cadastrar1.LineThickness = 2;
            this.Cadastrar1.Location = new System.Drawing.Point(109, 363);
            this.Cadastrar1.Margin = new System.Windows.Forms.Padding(4);
            this.Cadastrar1.Name = "Cadastrar1";
            this.Cadastrar1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Cadastrar1.Size = new System.Drawing.Size(179, 33);
            this.Cadastrar1.TabIndex = 175;
            this.Cadastrar1.Click += new System.EventHandler(this.Cadastrar1_Click);
            // 
            // txt_parc1
            // 
            this.txt_parc1.BackColor = System.Drawing.Color.White;
            this.txt_parc1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_parc1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_parc1.Location = new System.Drawing.Point(32, 296);
            this.txt_parc1.Name = "txt_parc1";
            this.txt_parc1.Size = new System.Drawing.Size(147, 20);
            this.txt_parc1.TabIndex = 174;
            this.txt_parc1.Text = "0";
            this.txt_parc1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_quant1
            // 
            this.txt_quant1.BackColor = System.Drawing.Color.White;
            this.txt_quant1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_quant1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_quant1.Location = new System.Drawing.Point(224, 235);
            this.txt_quant1.Name = "txt_quant1";
            this.txt_quant1.Size = new System.Drawing.Size(147, 20);
            this.txt_quant1.TabIndex = 173;
            this.txt_quant1.Text = "0";
            this.txt_quant1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_valor1
            // 
            this.txt_valor1.BackColor = System.Drawing.Color.White;
            this.txt_valor1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_valor1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_valor1.Location = new System.Drawing.Point(32, 235);
            this.txt_valor1.Name = "txt_valor1";
            this.txt_valor1.Size = new System.Drawing.Size(147, 20);
            this.txt_valor1.TabIndex = 172;
            this.txt_valor1.Text = "00,00";
            this.txt_valor1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_venc1
            // 
            this.txt_venc1.CalendarFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_venc1.CalendarMonthBackground = System.Drawing.Color.WhiteSmoke;
            this.txt_venc1.CustomFormat = "yyyy-MM-dd";
            this.txt_venc1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_venc1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txt_venc1.Location = new System.Drawing.Point(32, 110);
            this.txt_venc1.Name = "txt_venc1";
            this.txt_venc1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_venc1.Size = new System.Drawing.Size(147, 27);
            this.txt_venc1.TabIndex = 171;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label15.Location = new System.Drawing.Point(22, 265);
            this.label15.Name = "label15";
            this.label15.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label15.Size = new System.Drawing.Size(128, 21);
            this.label15.TabIndex = 81;
            this.label15.Text = "Nº de parcelas:";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(16, 289);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(179, 34);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox7.TabIndex = 82;
            this.pictureBox7.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label14.Location = new System.Drawing.Point(214, 204);
            this.label14.Name = "label14";
            this.label14.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label14.Size = new System.Drawing.Size(112, 21);
            this.label14.TabIndex = 79;
            this.label14.Text = "Quantidade:";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(208, 228);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(179, 34);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox6.TabIndex = 80;
            this.pictureBox6.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label12.Location = new System.Drawing.Point(22, 204);
            this.label12.Name = "label12";
            this.label12.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label12.Size = new System.Drawing.Size(122, 21);
            this.label12.TabIndex = 77;
            this.label12.Text = "Valor em reais:";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(16, 228);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(179, 34);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox5.TabIndex = 78;
            this.pictureBox5.TabStop = false;
            // 
            // txt_desc1
            // 
            this.txt_desc1.BackColor = System.Drawing.Color.White;
            this.txt_desc1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_desc1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_desc1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.txt_desc1.Location = new System.Drawing.Point(32, 174);
            this.txt_desc1.Name = "txt_desc1";
            this.txt_desc1.Size = new System.Drawing.Size(341, 20);
            this.txt_desc1.TabIndex = 75;
            this.txt_desc1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(16, 167);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(371, 34);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 76;
            this.pictureBox4.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label11.Location = new System.Drawing.Point(25, 143);
            this.label11.Name = "label11";
            this.label11.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label11.Size = new System.Drawing.Size(91, 21);
            this.label11.TabIndex = 74;
            this.label11.Text = "Descrição:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label10.Location = new System.Drawing.Point(25, 82);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label10.Size = new System.Drawing.Size(110, 21);
            this.label10.TabIndex = 72;
            this.label10.Text = "Vencimento:";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(16, 106);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(179, 34);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 73;
            this.pictureBox3.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label13.Location = new System.Drawing.Point(22, 21);
            this.label13.Name = "label13";
            this.label13.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label13.Size = new System.Drawing.Size(103, 21);
            this.label13.TabIndex = 68;
            this.label13.Text = "Fornecedor:";
            // 
            // txt_fornecedor
            // 
            this.txt_fornecedor.BackColor = System.Drawing.Color.White;
            this.txt_fornecedor.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_fornecedor.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_fornecedor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.txt_fornecedor.Location = new System.Drawing.Point(29, 52);
            this.txt_fornecedor.Name = "txt_fornecedor";
            this.txt_fornecedor.Size = new System.Drawing.Size(341, 20);
            this.txt_fornecedor.TabIndex = 67;
            this.txt_fornecedor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox14.Image")));
            this.pictureBox14.Location = new System.Drawing.Point(13, 45);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(371, 34);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 69;
            this.pictureBox14.TabStop = false;
            // 
            // FCaixa
            // 
            this.FCaixa.AutoSize = true;
            this.FCaixa.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FCaixa.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.FCaixa.Location = new System.Drawing.Point(20, 198);
            this.FCaixa.Name = "FCaixa";
            this.FCaixa.Size = new System.Drawing.Size(189, 28);
            this.FCaixa.TabIndex = 181;
            this.FCaixa.Text = "Fluxo de Caixa";
            this.FCaixa.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.FCaixa.Click += new System.EventHandler(this.FCaixa_Click);
            // 
            // Receber
            // 
            this.Receber.AutoSize = true;
            this.Receber.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Receber.ForeColor = System.Drawing.Color.MediumSeaGreen;
            this.Receber.Location = new System.Drawing.Point(222, 198);
            this.Receber.Name = "Receber";
            this.Receber.Size = new System.Drawing.Size(139, 28);
            this.Receber.TabIndex = 182;
            this.Receber.Text = "A Receber";
            this.Receber.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Receber.Click += new System.EventHandler(this.Receber_Click);
            // 
            // Pagar
            // 
            this.Pagar.AutoSize = true;
            this.Pagar.BackColor = System.Drawing.Color.Transparent;
            this.Pagar.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pagar.ForeColor = System.Drawing.Color.Firebrick;
            this.Pagar.Location = new System.Drawing.Point(386, 198);
            this.Pagar.Name = "Pagar";
            this.Pagar.Size = new System.Drawing.Size(106, 28);
            this.Pagar.TabIndex = 183;
            this.Pagar.Text = "A Pagar";
            this.Pagar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Pagar.Click += new System.EventHandler(this.Pagar_Click);
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.panel5.Location = new System.Drawing.Point(11, 243);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1151, 1);
            this.panel5.TabIndex = 185;
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel6.Controls.Add(this.ID);
            this.panel6.Controls.Add(this.txt_venc2);
            this.panel6.Controls.Add(this.label18);
            this.panel6.Controls.Add(this.pictureBox13);
            this.panel6.Controls.Add(this.Excluir2);
            this.panel6.Controls.Add(this.Alterar2);
            this.panel6.Controls.Add(this.Cadastrar2);
            this.panel6.Controls.Add(this.txt_parc2);
            this.panel6.Controls.Add(this.txt_quant2);
            this.panel6.Controls.Add(this.txt_valor2);
            this.panel6.Controls.Add(this.txt_emi);
            this.panel6.Controls.Add(this.dataGridView2);
            this.panel6.Controls.Add(this.label6);
            this.panel6.Controls.Add(this.pictureBox2);
            this.panel6.Controls.Add(this.label7);
            this.panel6.Controls.Add(this.pictureBox8);
            this.panel6.Controls.Add(this.label8);
            this.panel6.Controls.Add(this.pictureBox9);
            this.panel6.Controls.Add(this.txt_desc2);
            this.panel6.Controls.Add(this.pictureBox10);
            this.panel6.Controls.Add(this.label9);
            this.panel6.Controls.Add(this.label16);
            this.panel6.Controls.Add(this.pictureBox11);
            this.panel6.Controls.Add(this.label17);
            this.panel6.Controls.Add(this.txt_cliente);
            this.panel6.Controls.Add(this.pictureBox12);
            this.panel6.Location = new System.Drawing.Point(12, 253);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1155, 523);
            this.panel6.TabIndex = 186;
            this.panel6.Visible = false;
            // 
            // Excluir2
            // 
            this.Excluir2.BackColor = System.Drawing.Color.Transparent;
            this.Excluir2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Excluir2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Excluir2.BorderRadius = 12;
            this.Excluir2.ButtonText = "Excluir";
            this.Excluir2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Excluir2.Font_Size = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Excluir2.ForeColors = System.Drawing.Color.White;
            this.Excluir2.HoverBackground = System.Drawing.Color.MediumSeaGreen;
            this.Excluir2.HoverBorder = System.Drawing.Color.MediumSeaGreen;
            this.Excluir2.HoverFontColor = System.Drawing.Color.White;
            this.Excluir2.LineThickness = 2;
            this.Excluir2.Location = new System.Drawing.Point(109, 445);
            this.Excluir2.Margin = new System.Windows.Forms.Padding(4);
            this.Excluir2.Name = "Excluir2";
            this.Excluir2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Excluir2.Size = new System.Drawing.Size(179, 33);
            this.Excluir2.TabIndex = 177;
            this.Excluir2.Click += new System.EventHandler(this.Excluir2_Click);
            // 
            // Alterar2
            // 
            this.Alterar2.BackColor = System.Drawing.Color.Transparent;
            this.Alterar2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Alterar2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Alterar2.BorderRadius = 12;
            this.Alterar2.ButtonText = "Alterar";
            this.Alterar2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alterar2.Font_Size = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alterar2.ForeColors = System.Drawing.Color.White;
            this.Alterar2.HoverBackground = System.Drawing.Color.MediumSeaGreen;
            this.Alterar2.HoverBorder = System.Drawing.Color.MediumSeaGreen;
            this.Alterar2.HoverFontColor = System.Drawing.Color.White;
            this.Alterar2.LineThickness = 2;
            this.Alterar2.Location = new System.Drawing.Point(109, 404);
            this.Alterar2.Margin = new System.Windows.Forms.Padding(4);
            this.Alterar2.Name = "Alterar2";
            this.Alterar2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Alterar2.Size = new System.Drawing.Size(179, 33);
            this.Alterar2.TabIndex = 176;
            this.Alterar2.Click += new System.EventHandler(this.Alterar2_Click);
            // 
            // Cadastrar2
            // 
            this.Cadastrar2.BackColor = System.Drawing.Color.Transparent;
            this.Cadastrar2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Cadastrar2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(182)))), ((int)(((byte)(117)))));
            this.Cadastrar2.BorderRadius = 12;
            this.Cadastrar2.ButtonText = "Cadastrar";
            this.Cadastrar2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cadastrar2.Font_Size = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cadastrar2.ForeColors = System.Drawing.Color.White;
            this.Cadastrar2.HoverBackground = System.Drawing.Color.MediumSeaGreen;
            this.Cadastrar2.HoverBorder = System.Drawing.Color.MediumSeaGreen;
            this.Cadastrar2.HoverFontColor = System.Drawing.Color.White;
            this.Cadastrar2.LineThickness = 2;
            this.Cadastrar2.Location = new System.Drawing.Point(109, 363);
            this.Cadastrar2.Margin = new System.Windows.Forms.Padding(4);
            this.Cadastrar2.Name = "Cadastrar2";
            this.Cadastrar2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Cadastrar2.Size = new System.Drawing.Size(179, 33);
            this.Cadastrar2.TabIndex = 175;
            this.Cadastrar2.Click += new System.EventHandler(this.Cadastrar2_Click);
            // 
            // txt_parc2
            // 
            this.txt_parc2.BackColor = System.Drawing.Color.White;
            this.txt_parc2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_parc2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_parc2.Location = new System.Drawing.Point(32, 296);
            this.txt_parc2.Name = "txt_parc2";
            this.txt_parc2.Size = new System.Drawing.Size(147, 20);
            this.txt_parc2.TabIndex = 174;
            this.txt_parc2.Text = "0";
            this.txt_parc2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_quant2
            // 
            this.txt_quant2.BackColor = System.Drawing.Color.White;
            this.txt_quant2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_quant2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_quant2.Location = new System.Drawing.Point(224, 235);
            this.txt_quant2.Name = "txt_quant2";
            this.txt_quant2.Size = new System.Drawing.Size(147, 20);
            this.txt_quant2.TabIndex = 173;
            this.txt_quant2.Text = "0";
            this.txt_quant2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_valor2
            // 
            this.txt_valor2.BackColor = System.Drawing.Color.White;
            this.txt_valor2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_valor2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_valor2.Location = new System.Drawing.Point(32, 235);
            this.txt_valor2.Name = "txt_valor2";
            this.txt_valor2.Size = new System.Drawing.Size(147, 20);
            this.txt_valor2.TabIndex = 172;
            this.txt_valor2.Text = "00,00";
            this.txt_valor2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_emi
            // 
            this.txt_emi.CalendarFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_emi.CalendarMonthBackground = System.Drawing.Color.WhiteSmoke;
            this.txt_emi.CustomFormat = "yyyy-MM-dd";
            this.txt_emi.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_emi.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txt_emi.Location = new System.Drawing.Point(32, 110);
            this.txt_emi.Name = "txt_emi";
            this.txt_emi.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_emi.Size = new System.Drawing.Size(147, 27);
            this.txt_emi.TabIndex = 171;
            // 
            // dataGridView2
            // 
            this.dataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.Column2,
            this.Column3,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn13,
            this.Column1});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView2.Location = new System.Drawing.Point(416, 27);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(730, 483);
            this.dataGridView2.TabIndex = 169;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label6.Location = new System.Drawing.Point(22, 265);
            this.label6.Name = "label6";
            this.label6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label6.Size = new System.Drawing.Size(128, 21);
            this.label6.TabIndex = 81;
            this.label6.Text = "Nº de parcelas:";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(16, 289);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(179, 34);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 82;
            this.pictureBox2.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label7.Location = new System.Drawing.Point(214, 204);
            this.label7.Name = "label7";
            this.label7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label7.Size = new System.Drawing.Size(112, 21);
            this.label7.TabIndex = 79;
            this.label7.Text = "Quantidade:";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(208, 228);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(179, 34);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox8.TabIndex = 80;
            this.pictureBox8.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label8.Location = new System.Drawing.Point(22, 204);
            this.label8.Name = "label8";
            this.label8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label8.Size = new System.Drawing.Size(122, 21);
            this.label8.TabIndex = 77;
            this.label8.Text = "Valor em reais:";
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(16, 228);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(179, 34);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox9.TabIndex = 78;
            this.pictureBox9.TabStop = false;
            // 
            // txt_desc2
            // 
            this.txt_desc2.BackColor = System.Drawing.Color.White;
            this.txt_desc2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_desc2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_desc2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.txt_desc2.Location = new System.Drawing.Point(32, 174);
            this.txt_desc2.Name = "txt_desc2";
            this.txt_desc2.Size = new System.Drawing.Size(341, 20);
            this.txt_desc2.TabIndex = 75;
            this.txt_desc2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(16, 167);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(371, 34);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 76;
            this.pictureBox10.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label9.Location = new System.Drawing.Point(25, 143);
            this.label9.Name = "label9";
            this.label9.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label9.Size = new System.Drawing.Size(91, 21);
            this.label9.TabIndex = 74;
            this.label9.Text = "Descrição:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label16.Location = new System.Drawing.Point(25, 82);
            this.label16.Name = "label16";
            this.label16.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label16.Size = new System.Drawing.Size(74, 21);
            this.label16.TabIndex = 72;
            this.label16.Text = "Emissão:";
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(16, 106);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(179, 34);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox11.TabIndex = 73;
            this.pictureBox11.TabStop = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label17.Location = new System.Drawing.Point(22, 21);
            this.label17.Name = "label17";
            this.label17.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label17.Size = new System.Drawing.Size(70, 21);
            this.label17.TabIndex = 68;
            this.label17.Text = "Cliente:";
            // 
            // txt_cliente
            // 
            this.txt_cliente.BackColor = System.Drawing.Color.White;
            this.txt_cliente.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_cliente.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_cliente.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.txt_cliente.Location = new System.Drawing.Point(29, 52);
            this.txt_cliente.Name = "txt_cliente";
            this.txt_cliente.Size = new System.Drawing.Size(341, 20);
            this.txt_cliente.TabIndex = 67;
            this.txt_cliente.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12.Image")));
            this.pictureBox12.Location = new System.Drawing.Point(13, 45);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(371, 34);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 69;
            this.pictureBox12.TabStop = false;
            // 
            // txt_venc2
            // 
            this.txt_venc2.CalendarFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_venc2.CalendarMonthBackground = System.Drawing.Color.WhiteSmoke;
            this.txt_venc2.CustomFormat = "yyyy-MM-dd";
            this.txt_venc2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_venc2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txt_venc2.Location = new System.Drawing.Point(224, 110);
            this.txt_venc2.Name = "txt_venc2";
            this.txt_venc2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_venc2.Size = new System.Drawing.Size(147, 27);
            this.txt_venc2.TabIndex = 180;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.label18.Location = new System.Drawing.Point(217, 82);
            this.label18.Name = "label18";
            this.label18.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label18.Size = new System.Drawing.Size(110, 21);
            this.label18.TabIndex = 178;
            this.label18.Text = "Vencimento:";
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(208, 106);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(179, 34);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox13.TabIndex = 179;
            this.pictureBox13.TabStop = false;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "FC_emissao";
            this.dataGridViewTextBoxColumn7.HeaderText = "Data de emissão";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "FC_vencimento";
            this.dataGridViewTextBoxColumn8.HeaderText = "Data de vencimento";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "FC_pessoa";
            this.dataGridViewTextBoxColumn9.HeaderText = "Cliente";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "FC_desc";
            this.dataGridViewTextBoxColumn10.HeaderText = "Descrição";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "FC_valor_item";
            this.Column2.HeaderText = "Valor do Item";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "FC_quant";
            this.Column3.HeaderText = "Quantidade";
            this.Column3.Name = "Column3";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "FC_totalp";
            this.dataGridViewTextBoxColumn11.HeaderText = "Valor parcela";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "FC_parcelas";
            this.dataGridViewTextBoxColumn13.HeaderText = "Nº de parcelas";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "FC_entrada";
            this.Column1.HeaderText = "Total";
            this.Column1.Name = "Column1";
            // 
            // ID
            // 
            this.ID.AutoSize = true;
            this.ID.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.ID.Location = new System.Drawing.Point(284, 296);
            this.ID.Name = "ID";
            this.ID.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ID.Size = new System.Drawing.Size(27, 21);
            this.ID.TabIndex = 181;
            this.ID.Text = "ID";
            this.ID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ID.Visible = false;
            // 
            // dataGridView
            // 
            this.dataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn19,
            this.Column4,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView.Location = new System.Drawing.Point(13, 65);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.Size = new System.Drawing.Size(1138, 455);
            this.dataGridView.TabIndex = 180;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "FC_emissao";
            this.dataGridViewTextBoxColumn1.HeaderText = "Data de emissão";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "FC_vencimento";
            this.dataGridViewTextBoxColumn4.HeaderText = "Data de vencimento";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "FC_pessoa";
            this.dataGridViewTextBoxColumn12.HeaderText = "Cliente";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "FC_desc";
            this.dataGridViewTextBoxColumn14.HeaderText = "Descrição";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "FC_entrada";
            this.dataGridViewTextBoxColumn19.HeaderText = "Entradas";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "FC_saida";
            this.Column4.HeaderText = "Saídas";
            this.Column4.Name = "Column4";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "FC_valor_item";
            this.dataGridViewTextBoxColumn15.HeaderText = "Valor do Item";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "FC_quant";
            this.dataGridViewTextBoxColumn16.HeaderText = "Quantidade";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "FC_totalp";
            this.dataGridViewTextBoxColumn17.HeaderText = "Valor parcela";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "FC_parcelas";
            this.dataGridViewTextBoxColumn18.HeaderText = "Nº de parcelas";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // entradas
            // 
            this.entradas.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.entradas.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.entradas.BackColor = System.Drawing.Color.White;
            this.entradas.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.entradas.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Italic);
            this.entradas.ForeColor = System.Drawing.Color.MediumSeaGreen;
            this.entradas.Location = new System.Drawing.Point(488, 34);
            this.entradas.Name = "entradas";
            this.entradas.ReadOnly = true;
            this.entradas.Size = new System.Drawing.Size(192, 30);
            this.entradas.TabIndex = 181;
            this.entradas.Text = "0";
            this.entradas.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn23,
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn25,
            this.dataGridViewTextBoxColumn26,
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn28,
            this.dataGridViewTextBoxColumn29});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView1.Location = new System.Drawing.Point(416, 27);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(740, 502);
            this.dataGridView1.TabIndex = 181;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // ID1
            // 
            this.ID1.AutoSize = true;
            this.ID1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ID1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(108)))), ((int)(((byte)(146)))));
            this.ID1.Location = new System.Drawing.Point(284, 296);
            this.ID1.Name = "ID1";
            this.ID1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ID1.Size = new System.Drawing.Size(27, 21);
            this.ID1.TabIndex = 182;
            this.ID1.Text = "ID";
            this.ID1.Visible = false;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "FC_vencimento";
            this.dataGridViewTextBoxColumn21.HeaderText = "Data de vencimento";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "FC_pessoa";
            this.dataGridViewTextBoxColumn22.HeaderText = "Fornecedor";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "FC_desc";
            this.dataGridViewTextBoxColumn23.HeaderText = "Descrição";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "FC_entrada";
            this.dataGridViewTextBoxColumn24.HeaderText = "Entradas";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "FC_saida";
            this.dataGridViewTextBoxColumn25.HeaderText = "Saídas";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.DataPropertyName = "FC_valor_item";
            this.dataGridViewTextBoxColumn26.HeaderText = "Valor do Item";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.DataPropertyName = "FC_quant";
            this.dataGridViewTextBoxColumn27.HeaderText = "Quantidade";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.DataPropertyName = "FC_totalp";
            this.dataGridViewTextBoxColumn28.HeaderText = "Valor parcela";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.DataPropertyName = "FC_parcelas";
            this.dataGridViewTextBoxColumn29.HeaderText = "Nº de parcelas";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            // 
            // saidas
            // 
            this.saidas.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.saidas.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.saidas.BackColor = System.Drawing.Color.White;
            this.saidas.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.saidas.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Italic);
            this.saidas.ForeColor = System.Drawing.Color.Firebrick;
            this.saidas.Location = new System.Drawing.Point(728, 34);
            this.saidas.Name = "saidas";
            this.saidas.ReadOnly = true;
            this.saidas.Size = new System.Drawing.Size(192, 30);
            this.saidas.TabIndex = 182;
            this.saidas.Text = "0";
            this.saidas.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // resultado
            // 
            this.resultado.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.resultado.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.resultado.BackColor = System.Drawing.Color.White;
            this.resultado.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.resultado.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Italic);
            this.resultado.ForeColor = System.Drawing.Color.DarkGray;
            this.resultado.Location = new System.Drawing.Point(973, 34);
            this.resultado.Name = "resultado";
            this.resultado.ReadOnly = true;
            this.resultado.Size = new System.Drawing.Size(192, 30);
            this.resultado.TabIndex = 183;
            this.resultado.Text = "0";
            this.resultado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Odonto_contas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1175, 788);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.Pagar);
            this.Controls.Add(this.Receber);
            this.Controls.Add(this.FCaixa);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Odonto_contas";
            this.Text = "Odonto_contas";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Maximizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Fechar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Menorizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minimizar)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BEsquerda)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox Maximizar;
        private System.Windows.Forms.PictureBox Fechar;
        private System.Windows.Forms.PictureBox Menorizar;
        private System.Windows.Forms.PictureBox Minimizar;
        private JDragControl.JDragControl jDragControl1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.PictureBox BEsquerda;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label Pagar;
        private System.Windows.Forms.Label Receber;
        private System.Windows.Forms.Label FCaixa;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox Pesquisa;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.TextBox txt_desc1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_fornecedor;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.DateTimePicker txt_venc1;
        private System.Windows.Forms.TextBox txt_parc1;
        private System.Windows.Forms.TextBox txt_quant1;
        private System.Windows.Forms.TextBox txt_valor1;
        private JThinButton.JThinButton Cadastrar1;
        private JThinButton.JThinButton Alterar1;
        private JThinButton.JThinButton Excluir1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.DateTimePicker txt_venc2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox pictureBox13;
        private JThinButton.JThinButton Excluir2;
        private JThinButton.JThinButton Alterar2;
        private JThinButton.JThinButton Cadastrar2;
        private System.Windows.Forms.TextBox txt_parc2;
        private System.Windows.Forms.TextBox txt_quant2;
        private System.Windows.Forms.TextBox txt_valor2;
        private System.Windows.Forms.DateTimePicker txt_emi;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.TextBox txt_desc2;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txt_cliente;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.Label ID;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.TextBox entradas;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label ID1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.TextBox saidas;
        private System.Windows.Forms.TextBox resultado;
    }
}