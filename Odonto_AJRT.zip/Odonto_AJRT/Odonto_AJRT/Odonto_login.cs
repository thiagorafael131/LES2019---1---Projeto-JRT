﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;


namespace Odonto_AJRT
{
    public partial class form_1 : Form
    {
        public form_1()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }
        String cargo;

        MySqlConnection con = new MySqlConnection(@"server=localhost;user id=root;database=odonto_ajrt;
        persistsecurityinfo=True");//Conexão
        int i;//Contador para verificação

        private void Botão_Entrar_Click(object sender, EventArgs e)
        {
            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from tb_conta where Conta_usu = '" + txt_login.Text.Trim() + 
            "'and Conta_senha = '" + txt_senha.Text.Trim() + "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            i = Convert.ToInt32(dt.Rows.Count.ToString());

                if (i == 0)
                {
                    MessageBox.Show("Usuário ou senha Incorretos!!");
                    con.Close();
                }
                else
                {
                    MySqlDataReader MyReader1 = cmd.ExecuteReader();
                    while (MyReader1.Read())
                    {
                        cargo = MyReader1["FK_Cargo_id"].ToString();
                        if (cargo == "1")
                        {
                            main_odonto objFrmMain = new main_odonto(txt_login.Text);
                            this.Hide();
                            objFrmMain.Show();
                        }

                    else if (cargo == "2")
                    {
                        main_med_odonto objFrmMain = new main_med_odonto(txt_login.Text);
                        this.Hide();
                        objFrmMain.Show();
                    }

                    else if (cargo == "3")
                        {
                            main_sec_odonto objFrmMain = new main_sec_odonto(txt_login.Text);
                            this.Hide();
                            objFrmMain.Show();
                        }
                    }

                }
        }

        private void Fechar_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void Recupera_Click(object sender, EventArgs e)
        {
            Odonto_recuperacao objFrmMain = new Odonto_recuperacao();
            this.Hide();
            objFrmMain.Show();
        }

        private void txt_senha_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter)) {
                Botão_Entrar_Click(null,null);
            }
        }
    }
}
