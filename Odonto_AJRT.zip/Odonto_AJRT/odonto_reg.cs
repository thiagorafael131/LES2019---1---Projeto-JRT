﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft;
using Newtonsoft.Json;
using MySql.Data.MySqlClient;

namespace Odonto_AJRT
{
    public partial class odonto_reg : Form
    {
        public odonto_reg()
        {
            InitializeComponent();
        }

        public string BuscaCep(string dados, string cep)
        {
            /*possiveis dados
             * cep logradouro complemento bairro localidade uf unidade ibge gia
             */
            //VAI BUSCAR O TEXTO DO SITE/DOCUMENTO NO ENDERECO ABAIXO
            string ENDERECO = "https://viacep.com.br/ws/" + cep + "/json/";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(ENDERECO);
            request.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36";
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            if (response.StatusCode == HttpStatusCode.OK)
            {
                Stream receiveStream = response.GetResponseStream();
                StreamReader readStream = null;
                readStream = new StreamReader(receiveStream, Encoding.GetEncoding(response.CharacterSet));
                string data = readStream.ReadToEnd();
                dynamic data2 = JsonConvert.DeserializeObject(data);
                return data2[dados];
            }
            else { return "ERRO"; }
        }

        private void textCep_Leave(object sender, EventArgs e)
        {
            string CEP = txtCep.Text;
            txtEstado.Text = BuscaCep("uf",CEP);
            txtCidade.Text = BuscaCep("localidade", CEP);
            txtBairro.Text = BuscaCep("bairro", CEP);
            txtRua.Text = BuscaCep("logradouro", CEP);
        }

        private void odonto_reg_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void jThinButton2_Click(object sender, EventArgs e)
        {
            try
            {
                //This is my connection string i have assigned the database file address path  
                string MyConnection1 = "server=localhost;user id=root;database=odonto_ajrt;persistsecurityinfo=True;allowuservariables=True";
                //This is my insert query in which i am taking input from the user through windows forms  
                string Query1 = "insert into tb_funcionario(Fun_nome,Fun_sobrenome,Fun_email,Fun_tel,Fun_cel,Fun_cep,Fun_estado,Fun_cidade,Fun_bairro,Fun_rua,Fun_num) values('" + this.txt_nome.Text + "','" + this.txt_sobrenome.Text + "','" + this.txt_email.Text + "','" + this.txt_tel.Text + "','" + this.txt_cel.Text + "','" + this.txtCep.Text + "','" + this.txtEstado.Text + "','" + this.txtCidade.Text + "','" + this.txtBairro.Text + "','" + this.txtRua.Text + "','" + this.txtNum.Text + "');";
                //This is  MySqlConnection here i have created the object and pass my connection string.  
                MySqlConnection MyConn1 = new MySqlConnection(MyConnection1);
                //This is command class which will handle the query and connection object.  
                MySqlCommand MyCommand1 = new MySqlCommand(Query1, MyConn1);
                MySqlDataReader MyReader1;
                string Query2 = "insert into tb_conta(Conta_usu,Conta_senha,FK_Fun_id,FK_Cargo_id) values('" + this.txt_usu.Text + "','" + this.txt_senha.Text + "','(select Fun_id from tb_funcionario ORDER BY Fun_id DESC LIMIT 1)','(select Cargo_id from tb_cargo where Cargo_nome='" + this.CB_cargo.Text + "')');";
                MySqlCommand MyCommand2 = new MySqlCommand(Query2, MyConn1);
                MySqlDataReader MyReader2;
                MyConn1.Open();
                MyReader1 = MyCommand1.ExecuteReader();     // Here our query will be executed and data saved into the database.  
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Save Data");
                while (MyReader1.Read())
                {
                }
                MyConn1.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        
    }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void lb_fechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
    }
}
